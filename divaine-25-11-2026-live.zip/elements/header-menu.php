 
    <!--Preloader-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!--Preloader-end -->

    <!-- Scroll-top -->
    <button class="scroll__top scroll-to-target" data-target="php">
        <svg width="22" height="21" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M11 19.3848V0.999995M11 0.999995L1.80762 10.1924M11 0.999995L20.1924 10.1924" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        </svg>
    </button>
    <!-- Scroll-top-end-->

    <!-- header-area -->
    <header class="transparent-header">
        <div class="tg-header__top">
            <div class="container custom-container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="tg-header__top-menu">
                            <ul class="list-wrap">
                                <!-- <li>
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15 7.54545C15 12.6364 8.5 17 8.5 17C8.5 17 2 12.6364 2 7.54545C2 5.80949 2.68482 4.14463 3.90381 2.91712C5.12279 1.68961 6.77609 1 8.5 1C10.2239 1 11.8772 1.68961 13.0962 2.91712C14.3152 4.14463 15 5.80949 15 7.54545Z" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M8.5 9.72727C9.69662 9.72727 10.6667 8.75044 10.6667 7.54545C10.6667 6.34047 9.69662 5.36364 8.5 5.36364C7.30338 5.36364 6.33333 6.34047 6.33333 7.54545C6.33333 8.75044 7.30338 9.72727 8.5 9.72727Z" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                     HONG KONG
                                </li> -->
                                <li>
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.9718 12.4817V14.5893C15.9726 14.7849 15.9325 14.9786 15.8542 15.1578C15.7758 15.3371 15.6608 15.498 15.5167 15.6303C15.3725 15.7626 15.2023 15.8633 15.0169 15.9259C14.8316 15.9886 14.6352 16.0119 14.4403 15.9943C12.2786 15.7594 10.202 15.0207 8.37757 13.8376C6.68016 12.7589 5.24105 11.3198 4.16244 9.62243C2.97517 7.78969 2.2363 5.70306 2.0057 3.53156C1.98815 3.33729 2.01123 3.1415 2.0735 2.95664C2.13576 2.77178 2.23583 2.60191 2.36734 2.45785C2.49885 2.31378 2.65891 2.19868 2.83734 2.11986C3.01577 2.04105 3.20866 2.00025 3.40372 2.00007H5.51128C5.85222 1.99671 6.18275 2.11744 6.44126 2.33976C6.69976 2.56208 6.86861 2.87081 6.91633 3.20841C7.00528 3.88287 7.17025 4.54511 7.40809 5.18249C7.50261 5.43394 7.52307 5.70721 7.46704 5.96993C7.41101 6.23265 7.28084 6.4738 7.09196 6.66481L6.19976 7.55701C7.19983 9.31581 8.65609 10.7721 10.4149 11.7721L11.3071 10.8799C11.4981 10.6911 11.7392 10.5609 12.002 10.5049C12.2647 10.4488 12.538 10.4693 12.7894 10.5638C13.4268 10.8016 14.089 10.9666 14.7635 11.0556C15.1048 11.1037 15.4164 11.2756 15.6392 11.5386C15.862 11.8015 15.9804 12.1372 15.9718 12.4817Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    <a href="tel: +971 552783479"> +971 552783479</a><span>/</span>
                                    <span><a href="tel:+852 51699601">+852 51699601</a></span>
                                </li>
                                <li>
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M17 4.5C17 3.675 16.28 3 15.4 3H2.6C1.72 3 1 3.675 1 4.5M17 4.5V13.5C17 14.325 16.28 15 15.4 15H2.6C1.72 15 1 14.325 1 13.5V4.5M17 4.5L9 9.75007L1 4.5" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    <a href="mailto:hello@divainetech.io">hello@divainetech.io</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="sticky-header" class="tg-header__area">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-12">
                        <div class="tgmenu__wrap">
                            <nav class="tgmenu__nav">
                                <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/divaine-tech-header.png" alt="Logo"></a>
                                </div>
                                <div class="tgmenu__navbar-wrap tgmenu__main-menu d-none d-xl-flex">
                                    <ul class="navigation">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="services.php">Services</a></li>
                                        <li><a href="project.php">Projects</a></li>
                                        <li><a href="blog.php">Blog</a></li>
                                        <li class="menu-item-has-children"><a href="#">Pages</a>
                                            <ul class="sub-menu">
                                                <li><a href="about.php">About Us</a></li>
                                                <li><a href="why-choose-us.php">Why choose Us</a></li>
                                                <li><a href="career.php">Career Page</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                                <div class="tgmenu__action">
                                    <ul class="list-wrap">
                                        <li class="header-btn">
                                            <a href="contact.php" class="tg-btn">Get a Quote</a>
                                        </li>
                                        <li class="offCanvas-menu">
                                            <a href="#!" class="menu-tigger">
                                                <svg width="19" height="20" viewBox="0 0 19 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="7.19995" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="14.3999" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect y="8" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="7.19995" y="8" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="14.3999" y="8" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect y="16" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="7.19995" y="16" width="4" height="4" rx="2" fill="currentColor" />
                                                    <rect x="14.3999" y="16" width="4" height="4" rx="2" fill="currentColor" />
                                                </svg>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="mobile-nav-toggler">
                                    <svg width="19" height="20" viewBox="0 0 19 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="7.19995" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="14.3999" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect y="8" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="7.19995" y="8" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="14.3999" y="8" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect y="16" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="7.19995" y="16" width="4" height="4" rx="2" fill="currentColor" />
                                        <rect x="14.3999" y="16" width="4" height="4" rx="2" fill="currentColor" />
                                    </svg>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Mobile Menu  -->
        <div class="tgmobile__menu">
            <nav class="tgmobile__menu-box">
                <div class="close-btn"><i class="tg-flaticon-close-1"></i></div>
                <div class="nav-logo">
                    <a href="index.php"><img src="assets/img/logo/divaine-tech-header.png" alt="Logo"></a>
                </div>
                <div class="tgmobile__search">
                    <form action="#">
                        <input type="text" placeholder="Search here...">
                        <button>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M22.6666 22.6667L18.0329 18.033M20.9079 11.1207C20.9079 16.5261 16.526 20.908 11.1206 20.908C5.71519 20.908 1.33325 16.5261 1.33325 11.1207C1.33325 5.71528 5.71519 1.33334 11.1206 1.33334C16.526 1.33334 20.9079 5.71528 20.9079 11.1207Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                        </button>
                    </form>
                </div>
                <div class="tgmobile__menu-outer">
                <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="social-links">
                    <ul class="list-wrap">
                        <li>
                            <a href="https://www.facebook.com/" target="_blank">
                                <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://x.com/" target="_blank">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/" target="_blank">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                </svg>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.pinterest.com/" target="_blank">
                                <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                </svg>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="tgmobile__menu-backdrop"></div>
        <!-- End Mobile Menu -->

        <!-- header-search -->
        <div class="search__popup">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="search__wrapper">
                            <div class="search__close">
                                <button type="button" class="search-close-btn">
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M17 1L1 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                        <path d="M1 1L17 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round"></path>
                                    </svg>
                                </button>
                            </div>
                            <div class="search__form">
                                <form action="#">
                                    <div class="search__input">
                                        <input class="search-input-field" type="text" placeholder="Type keywords here">
                                        <span class="search-focus-border"></span>
                                        <button>
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.55 18.1C14.272 18.1 18.1 14.272 18.1 9.55C18.1 4.82797 14.272 1 9.55 1C4.82797 1 1 4.82797 1 9.55C1 14.272 4.82797 18.1 9.55 18.1Z"
                                                    stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round"></path>
                                                <path d="M19.0002 19.0002L17.2002 17.2002" stroke="currentColor"
                                                    stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="search-popup-overlay"></div>
        <!-- header-search-end -->

        <!-- offCanvas-menu -->
        <div class="offCanvas__info">
            <div class="offCanvas__close-icon menu-close">
                <button>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 1L1 13M1 1L13 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </button>
            </div>
            <div class="offCanvas__logo mb-30">
                <a href="index.php"><img src="assets/img/logo/divaine-tech-header.png" alt="Logo"></a>
            </div>
            <div class="offCanvas__content">
                <p> Divaine Tech is the most enticing, creative and modern Premium WordPress Theme suitable for any business or corporate websites.</p>
            </div>
             <div class="offCanvas__info-wrap mb-30">
                <h2 class="offCanvas__title">Contact Details</h2>
                <div class="offCanvas__info-list">
                        <?php
                    $sideOffices = require __DIR__ . '/offices-data.php';
                    foreach ($sideOffices as $office):
                        $label = htmlspecialchars($office['label'], ENT_QUOTES, 'UTF-8');
                        $lines = array_map(function ($l) { return htmlspecialchars($l, ENT_QUOTES, 'UTF-8'); }, $office['lines']);
                        $mapUrl = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(implode(' ', $office['lines']));
                    ?>
                    <div class="offCanvas__info-list-item offCanvas__office d-flex align-items-start gap-3 mb-4">
                        <div class="icon flex-shrink-0">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.9998 10.0606C19.9998 16.8485 11.3332 22.6667 11.3332 22.6667C11.3332 22.6667 2.6665 16.8485 2.6665 10.0606C2.6665 7.746 3.5796 5.52618 5.20491 3.8895C6.83023 2.25282 9.03463 1.33334 11.3332 1.33334C13.6317 1.33334 15.8361 2.25282 17.4614 3.8895C19.0867 5.52618 19.9998 7.746 19.9998 10.0606Z" stroke="currentColor" stroke-width="1.73333" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M11.3332 12.9697C12.9287 12.9697 14.2221 11.6673 14.2221 10.0606C14.2221 8.45397 12.9287 7.15153 11.3332 7.15153C9.73768 7.15153 8.44428 8.45397 8.44428 10.0606C8.44428 11.6673 9.73768 12.9697 11.3332 12.9697Z" stroke="currentColor" stroke-width="1.73333" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                        <div class="flex-grow-1">
                            <h3 class="fs-6 fw-bold text-uppercase mb-1" style="color: var(--tg-theme-primary); letter-spacing: .04em;"><?= $label ?></h3>
                            <address class="mb-1 lh-base" style="font-size: 15px;">
                                <?= implode('<br>', $lines) ?>
                            </address>
                            <a href="<?= htmlspecialchars($mapUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" class="small fw-semibold text-decoration-none">Get directions &rarr;</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div class="offCanvas__info-list-item">
                        <div class="icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21.2956 16.6422V19.4523C21.2967 19.7132 21.2432 19.9714 21.1387 20.2104C21.0342 20.4495 20.8809 20.664 20.6887 20.8404C20.4965 21.0167 20.2695 21.151 20.0224 21.2346C19.7753 21.3182 19.5134 21.3492 19.2536 21.3257C16.3712 21.0125 13.6025 20.0276 11.1699 18.4501C8.90672 17.0119 6.9879 15.0931 5.54976 12.8299C3.96673 10.3862 2.98157 7.60406 2.67411 4.70874C2.6507 4.44972 2.68148 4.18865 2.7645 3.94217C2.84751 3.6957 2.98094 3.4692 3.15629 3.27712C3.33163 3.08503 3.54505 2.93156 3.78296 2.82647C4.02087 2.72139 4.27805 2.66699 4.53813 2.66675H7.34822C7.8028 2.66227 8.2435 2.82325 8.58818 3.11967C8.93285 3.41609 9.15798 3.82773 9.22161 4.27786C9.34021 5.17715 9.56018 6.06014 9.87729 6.90998C10.0033 7.24524 10.0306 7.60961 9.95589 7.9599C9.88118 8.31019 9.70762 8.63173 9.45578 8.88641L8.26618 10.076C9.59962 12.4211 11.5413 14.3627 13.8864 15.6962L15.076 14.5066C15.3306 14.2547 15.6522 14.0812 16.0025 14.0065C16.3527 13.9318 16.7171 13.959 17.0524 14.0851C17.9022 14.4022 18.7852 14.6221 19.6845 14.7408C20.1395 14.8049 20.5551 15.0341 20.8521 15.3847C21.1492 15.7353 21.307 16.1829 21.2956 16.6422Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                        <a href="tel: +971 552783479">Dubai : +971 552783479</a> 
                        
                    </div>

                    <div class="offCanvas__info-list-item">
                        <div class="icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21.2956 16.6422V19.4523C21.2967 19.7132 21.2432 19.9714 21.1387 20.2104C21.0342 20.4495 20.8809 20.664 20.6887 20.8404C20.4965 21.0167 20.2695 21.151 20.0224 21.2346C19.7753 21.3182 19.5134 21.3492 19.2536 21.3257C16.3712 21.0125 13.6025 20.0276 11.1699 18.4501C8.90672 17.0119 6.9879 15.0931 5.54976 12.8299C3.96673 10.3862 2.98157 7.60406 2.67411 4.70874C2.6507 4.44972 2.68148 4.18865 2.7645 3.94217C2.84751 3.6957 2.98094 3.4692 3.15629 3.27712C3.33163 3.08503 3.54505 2.93156 3.78296 2.82647C4.02087 2.72139 4.27805 2.66699 4.53813 2.66675H7.34822C7.8028 2.66227 8.2435 2.82325 8.58818 3.11967C8.93285 3.41609 9.15798 3.82773 9.22161 4.27786C9.34021 5.17715 9.56018 6.06014 9.87729 6.90998C10.0033 7.24524 10.0306 7.60961 9.95589 7.9599C9.88118 8.31019 9.70762 8.63173 9.45578 8.88641L8.26618 10.076C9.59962 12.4211 11.5413 14.3627 13.8864 15.6962L15.076 14.5066C15.3306 14.2547 15.6522 14.0812 16.0025 14.0065C16.3527 13.9318 16.7171 13.959 17.0524 14.0851C17.9022 14.4022 18.7852 14.6221 19.6845 14.7408C20.1395 14.8049 20.5551 15.0341 20.8521 15.3847C21.1492 15.7353 21.307 16.1829 21.2956 16.6422Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                        <a href="tel:+852 51699601">Hong Kong : +852 51699601</a>
                    </div>
                    <div class="offCanvas__info-list-item">
                        <div class="icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M22.6668 6C22.6668 4.9 21.7068 4 20.5335 4H3.46683C2.2935 4 1.3335 4.9 1.3335 6M22.6668 6V18C22.6668 19.1 21.7068 20 20.5335 20H3.46683C2.2935 20 1.3335 19.1 1.3335 18V6M22.6668 6L12.0002 13.0001L1.3335 6" stroke="currentColor" stroke-width="1.46667" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                        <a href="mailto:hello@divainetech.io">hello@divainetech.io</a>
                    </div>
                </div>
            </div>
            <div class="offCanvas__social-wrap">
                <h2 class="offCanvas__title">Follow us</h2>
                <ul class="list-wrap">
                    <li>
                        <a href="javascript:void(0);" target="_blank">
                            <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" target="_blank">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/divaine_tech/" target="_blank">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="https://t.me/+z_3YlueLtaw4ZDFk" target="_blank">
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
     xmlns="http://www.w3.org/2000/svg">
    <path d="M21.5 3.5L18.2 20.1C17.95 21.27 17.27 21.56 16.3 21.02L10.9 17.04L8.3 19.54C8.01 19.83 7.77 20.07 7.2 20.07L7.59 14.57L17.6 5.53C18.04 5.14 17.5 4.92 16.91 5.31L4.54 13.1L-0.78 11.44C-1.94 11.08 -1.96 10.28 -0.54 9.74L20.26 1.72C21.22 1.36 22.06 1.94 21.5 3.5Z"
          fill="currentColor"/>
</svg>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="offCanvas__overly"></div>
        <!-- offCanvas-menu-end -->

    </header>
    <!-- header-area-end -->
