<?php
	include_once ('elements/header.php')
?>
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg fix" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h2 class="title"> Divaine Tech Careers</h2>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="index.php">Home</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">Career</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- career-area -->
        <section class="career__area section-py-120">
            <div class="container">
                <div class="career__slider-wrap">
                    <div class="swiper-container career__active" id="careerSlider" data-swiper-options='{
                        "loop": true,
                        "effect": "fade",
                        "autoplay": { "delay": 8000 },
                        "breakpoints": {
                            "0": { "spaceBetween": 0, "slidesPerView": 1 },
                            "375": { "spaceBetween": 0, "slidesPerView": 1 },
                            "575": { "spaceBetween": 0, "slidesPerView": 1 },
                            "768": { "spaceBetween": 0, "slidesPerView": 1 },
                            "992": { "spaceBetween": 0, "slidesPerView": 1 },
                            "1400": { "spaceBetween": 0, "slidesPerView": 1 }
                        },
                        "navigation": {
                            "nextEl": ".career-button-next",
                            "prevEl": ".career-button-prev"
                        }}'>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="career__img">
                                    <img src="assets/img/slider/h2_slider_bg01.jpg" alt="img">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="career__img">
                                    <img src="assets/img/slider/h2_slider_bg02.jpg" alt="img">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="career__img">
                                    <img src="assets/img/slider/h2_slider_bg03.jpg" alt="img">
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="career__img">
                                    <img src="assets/img/project/project_details.jpg" alt="img">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="career__nav-wrap">
                        <button class="career-button-prev">
                            <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.9997 7.99998H1.33301M1.33301 7.99998L7.99967 14.6666M1.33301 7.99998L7.99967 1.33331" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>
                        <button class="career-button-next">
                            <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.00033 7.99998H18.667M18.667 7.99998L12.0003 14.6666M18.667 7.99998L12.0003 1.33331" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="career__content">
                            <div class="section__title section__title-two mb-25">
                                <span class="sub-title"> Divaine Tech Careers</span>
                                <h2 class="title"> Divaine Tech is an IT company that helps businesses grow <br> with smart technology.</h2>
                            </div>
                            <p>Each demo built with Teba will look different. You can customize almost anything offer your website with onl fewlicks Each demo built with Teba will xceptional opportu nities with interdependent users.Each demo built with eba will look different. You can customize almost anything in the appearance offer your website with on few clicks  Each demo built with Teba will look differentUniquely.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- career-area-end -->

        <!-- company-benefit-area -->
        <section class="company__benefit-area section-pb-140">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 order-0 order-lg-2">
                        <div class="company__benefit-img">
                            <img src="assets/img/images/company.jpg" alt="img">
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="company__benefit-content">
                            <div class="section__title section__title-two mb-25">
                                <span class="sub-title">Company Benefits</span>
                                <h2 class="title">We Provide Awesome Benefits For Employees</h2>
                            </div>
                            <p>Each demo built with Teba will look different. You can customalmost anything in the ap pearance of your website witnly a few clicks ach demo built different.Each demo built with Teba will look different.</p>
                            <ul class="choose__list choose__list-three choose__list-four choose__list-five list-wrap">
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Excellent Culture & Environment
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Gym Facilities
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Relax & Sports zone
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Free Shuttle Service
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Dual Festival Bonuses
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Loyalty Bonus
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Annual Pleasure Tour
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Excellent Culture & Environment
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Meals, Coffee & Snacks
                                </li>
                                <li>
                                    <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                        <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Leave Encashment
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- company-benefit-area-end -->

        <!-- job-area -->
        <section class="job__area section-bg section-py-140">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section__title section__title-two text-center mb-50">
                            <span class="sub-title">Job Circular</span>
                            <h2 class="title">Ready to Join Our Team</h2>
                            <p>Each demo built with Teba will look different. You can customalmost anything appearance of your website witonly a few click</p>
                        </div>
                    </div>
                </div>
                <div class="row gutter-y-30">
                    <div class="col-lg-6 col-md-6">
                        <div class="job__item">
                            <ul class="list-wrap job__meta">
                                <li><span>Full time</span></li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.6671 8.38381C16.6671 14.0404 9.44488 18.8889 9.44488 18.8889C9.44488 18.8889 2.22266 14.0404 2.22266 8.38381C2.22266 6.45496 2.98357 4.60512 4.338 3.24122C5.69243 1.87732 7.52943 1.11108 9.44488 1.11108C11.3603 1.11108 13.1973 1.87732 14.5518 3.24122C15.9062 4.60512 16.6671 6.45496 16.6671 8.38381Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M9.44488 10.8081C10.7745 10.8081 11.8523 9.72268 11.8523 8.38381C11.8523 7.04494 10.7745 5.95957 9.44488 5.95957C8.1153 5.95957 7.03747 7.04494 7.03747 8.38381C7.03747 9.72268 8.1153 10.8081 9.44488 10.8081Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    New York City
                                </li>
                            </ul>
                            <h2 class="title"><a href="career-details.php">Digital Marketing Excutive</a></h2>
                            <p>when an unknown printer took a galley type and scramble dmake a type specimen book. It has survived not only five but also the leap centuries,</p>
                            <div class="job__bottom">
                                <span class="salary">$10,000 - $ 12,000 / Month</span>
                                <a href="career-details.php" class="tg-btn">Apply Now
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="job__item">
                            <ul class="list-wrap job__meta">
                                <li><span>Full time</span></li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.6671 8.38381C16.6671 14.0404 9.44488 18.8889 9.44488 18.8889C9.44488 18.8889 2.22266 14.0404 2.22266 8.38381C2.22266 6.45496 2.98357 4.60512 4.338 3.24122C5.69243 1.87732 7.52943 1.11108 9.44488 1.11108C11.3603 1.11108 13.1973 1.87732 14.5518 3.24122C15.9062 4.60512 16.6671 6.45496 16.6671 8.38381Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M9.44488 10.8081C10.7745 10.8081 11.8523 9.72268 11.8523 8.38381C11.8523 7.04494 10.7745 5.95957 9.44488 5.95957C8.1153 5.95957 7.03747 7.04494 7.03747 8.38381C7.03747 9.72268 8.1153 10.8081 9.44488 10.8081Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    New York City
                                </li>
                            </ul>
                            <h2 class="title"><a href="career-details.php">Sr.WordPress Developer</a></h2>
                            <p>when an unknown printer took a galley type and scramble dmake a type specimen book. It has survived not only five but also the leap centuries,</p>
                            <div class="job__bottom">
                                <span class="salary">$10,000 - $ 12,000 / Month</span>
                                <a href="career-details.php" class="tg-btn">Apply Now
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="job__item">
                            <ul class="list-wrap job__meta">
                                <li><span>Full time</span></li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.6671 8.38381C16.6671 14.0404 9.44488 18.8889 9.44488 18.8889C9.44488 18.8889 2.22266 14.0404 2.22266 8.38381C2.22266 6.45496 2.98357 4.60512 4.338 3.24122C5.69243 1.87732 7.52943 1.11108 9.44488 1.11108C11.3603 1.11108 13.1973 1.87732 14.5518 3.24122C15.9062 4.60512 16.6671 6.45496 16.6671 8.38381Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M9.44488 10.8081C10.7745 10.8081 11.8523 9.72268 11.8523 8.38381C11.8523 7.04494 10.7745 5.95957 9.44488 5.95957C8.1153 5.95957 7.03747 7.04494 7.03747 8.38381C7.03747 9.72268 8.1153 10.8081 9.44488 10.8081Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    New York City
                                </li>
                            </ul>
                            <h2 class="title"><a href="career-details.php">Product Designer</a></h2>
                            <p>when an unknown printer took a galley type and scramble dmake a type specimen book. It has survived not only five but also the leap centuries,</p>
                            <div class="job__bottom">
                                <span class="salary">$10,000 - $ 12,000 / Month</span>
                                <a href="career-details.php" class="tg-btn">Apply Now
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="job__item">
                            <ul class="list-wrap job__meta">
                                <li><span>Full time</span></li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M16.6671 8.38381C16.6671 14.0404 9.44488 18.8889 9.44488 18.8889C9.44488 18.8889 2.22266 14.0404 2.22266 8.38381C2.22266 6.45496 2.98357 4.60512 4.338 3.24122C5.69243 1.87732 7.52943 1.11108 9.44488 1.11108C11.3603 1.11108 13.1973 1.87732 14.5518 3.24122C15.9062 4.60512 16.6671 6.45496 16.6671 8.38381Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M9.44488 10.8081C10.7745 10.8081 11.8523 9.72268 11.8523 8.38381C11.8523 7.04494 10.7745 5.95957 9.44488 5.95957C8.1153 5.95957 7.03747 7.04494 7.03747 8.38381C7.03747 9.72268 8.1153 10.8081 9.44488 10.8081Z" stroke="currentColor" stroke-width="1.44444" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    New York City
                                </li>
                            </ul>
                            <h2 class="title"><a href="career-details.php">Jr.Content Writer</a></h2>
                            <p>when an unknown printer took a galley type and scramble dmake a type specimen book. It has survived not only five but also the leap centuries,</p>
                            <div class="job__bottom">
                                <span class="salary">$10,000 - $ 12,000 / Month</span>
                                <a href="career-details.php" class="tg-btn">Apply Now
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- job-area-end -->

        <!-- contact-area -->
        <section class="contact__area-three fix section-py-140">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="contact__content-two">
                            <div class="section__title section__title-two mb-25">
                                <span class="sub-title">Our security Contact us</span>
                                <h2 class="title">Let’s build an awesome project together</h2>
                            </div>
                            <p>Each demo built with Teba will look different. You can customize almost anything in the appearance of your website with only Each demo built with Teba will look different.</p>
                            <div class="contact__info-list contact__info-list-two">
                                <div class="contact__info-item contact__info-item-two">
                                    <div class="icon">
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M25 12.5761C25 21.0609 14.1667 28.3337 14.1667 28.3337C14.1667 28.3337 3.33334 21.0609 3.33334 12.5761C3.33334 9.68281 4.47471 6.90804 6.50635 4.86219C8.538 2.81634 11.2935 1.66699 14.1667 1.66699C17.0399 1.66699 19.7954 2.81634 21.827 4.86219C23.8586 6.90804 25 9.68281 25 12.5761Z" stroke="currentColor" stroke-width="2.16667" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M14.1667 16.2124C16.161 16.2124 17.7778 14.5844 17.7778 12.5761C17.7778 10.5678 16.161 8.93972 14.1667 8.93972C12.1723 8.93972 10.5556 10.5678 10.5556 12.5761C10.5556 14.5844 12.1723 16.2124 14.1667 16.2124Z" stroke="currentColor" stroke-width="2.16667" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <h2 class="title">Sydney Harbour Circular <br> City of Sydney,Australia.</h2>
                                    </div>
                                </div>
                                <div class="contact__info-item contact__info-item-two">
                                    <div class="icon">
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M28.3333 7.5C28.3333 6.125 27.1333 5 25.6667 5H4.33332C2.86666 5 1.66666 6.125 1.66666 7.5M28.3333 7.5V22.5C28.3333 23.875 27.1333 25 25.6667 25H4.33332C2.86666 25 1.66666 23.875 1.66666 22.5V7.5M28.3333 7.5L15 16.2501L1.66666 7.5" stroke="currentColor" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <h2 class="title"><a href="mailto:hello@divainetech.io">hello@divainetech.io</a></h2>
                                    </div>
                                </div>
                                <div class="contact__info-item contact__info-item-two">
                                    <div class="icon">
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M26.6197 20.8025V24.3151C26.6211 24.6412 26.5543 24.964 26.4236 25.2627C26.293 25.5615 26.1014 25.8297 25.8611 26.0502C25.6208 26.2706 25.3371 26.4384 25.0282 26.5429C24.7193 26.6474 24.392 26.6862 24.0672 26.6568C20.4643 26.2653 17.0034 25.0342 13.9626 23.0623C11.1336 21.2646 8.73509 18.8661 6.93742 16.0371C4.95862 12.9825 3.72718 9.50477 3.34285 5.88562C3.31359 5.56183 3.35207 5.2355 3.45584 4.92741C3.55961 4.61931 3.72639 4.33619 3.94557 4.09608C4.16475 3.85598 4.43153 3.66414 4.72891 3.53278C5.0263 3.40142 5.34777 3.33343 5.67288 3.33312H9.18548C9.75372 3.32753 10.3046 3.52875 10.7354 3.89927C11.1663 4.2698 11.4477 4.78435 11.5272 5.34702C11.6755 6.47113 11.9504 7.57486 12.3468 8.63716C12.5044 9.05624 12.5385 9.5117 12.4451 9.94956C12.3517 10.3874 12.1347 10.7893 11.8199 11.1077L10.3329 12.5947C11.9997 15.526 14.4268 17.9531 17.3582 19.6199L18.8452 18.1329C19.1635 17.8181 19.5654 17.6012 20.0033 17.5078C20.4411 17.4144 20.8966 17.4485 21.3157 17.606C22.378 18.0024 23.4817 18.2774 24.6058 18.4256C25.1746 18.5059 25.694 18.7923 26.0654 19.2306C26.4367 19.6688 26.634 20.2283 26.6197 20.8025Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <h2 class="title"><a href="tel: +971 552783479"> +971 552783479</a></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6" data-sal="slide-left" data-sal-duration="700" data-sal-delay="300">
                        <div class="contact__form-wrap-two contact__form-wrap-three">
                            <h2 class="title">Fill The Contact Form</h2>
                            <p>We’d love to hear from you, and we promise no spam</p>
                            <form id="contact-form" action="assets/mail.php" class="contact__form-two" method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="text" name="name" placeholder="Your Name">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-grp">
                                            <input type="number" name="number" placeholder="Phone Number">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-grp">
                                    <input type="email" name="email" placeholder="E-mail Address">
                                </div>
                                <div class="form-grp">
                                    <textarea name="message" placeholder="Write your message"></textarea>
                                </div>
                                <button type="submit" class="tg-btn">Send Message</button>
                            </form>
                            <p class="ajax-response mb-0"></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact-area-end -->
<?php
	include_once ('elements/footer.php');
?>