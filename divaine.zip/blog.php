<?php
	include_once ('elements/header.php')
?>
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg fix" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h2 class="title">Blogs</h2>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="index.php">Home</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">Latest Blogs</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- blog-post-area -->
        <section class="blog-post__area-four section-py-140">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="inner-blog-post-wrap">
                            <div class="blog-post__item-five">
                                <div class="blog-post__thumb-five">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img01.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-five">
                                    <ul class="blog-post__meta blog-post__meta-three list-wrap">
                                        <li>12 Sep, 2025</li>
                                        <li>by <a href="blog-details.php">Michel Richard</a></li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Get a few solutions to hire a best candidate</a></h2>
                                    <p>Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia- list advice beyond. Eed a little help from </p>
                                    <a href="blog-details.php" class="tg-btn">Read More
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="blog-post__item-five">
                                <div class="blog-post__thumb-five">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img02.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-five">
                                    <ul class="blog-post__meta blog-post__meta-three list-wrap">
                                        <li>12 Sep, 2025</li>
                                        <li>by <a href="blog-details.php">Michel Richard</a></li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Get a few solutions to hire a best candidate</a></h2>
                                    <p>Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia- list advice beyond. Eed a little help from </p>
                                    <a href="blog-details.php" class="tg-btn">Read More
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="blog-post__item-five">
                                <div class="blog-post__thumb-five">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img03.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-five">
                                    <ul class="blog-post__meta blog-post__meta-three list-wrap">
                                        <li>12 Sep, 2025</li>
                                        <li>by <a href="blog-details.php">Michel Richard</a></li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Get a few solutions to hire a best candidate</a></h2>
                                    <p>Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia- list advice beyond. Eed a little help from </p>
                                    <a href="blog-details.php" class="tg-btn">Read More
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="blog-post__item-five">
                                <div class="blog-post__thumb-five">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img04.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-five">
                                    <ul class="blog-post__meta blog-post__meta-three list-wrap">
                                        <li>12 Sep, 2025</li>
                                        <li>by <a href="blog-details.php">Michel Richard</a></li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Get a few solutions to hire a best candidate</a></h2>
                                    <p>Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia- list advice beyond. Eed a little help from </p>
                                    <a href="blog-details.php" class="tg-btn">Read More
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <nav class="pagination__wrap mt-40">
                            <ul class="list-wrap">
                                <li class="active"><a href="#">1</a></li>
                                <li><a href="blog.php">2</a></li>
                                <li><a href="blog.php">3</a></li>
                                <li><a href="blog.php">4</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-lg-4">
                        <aside class="blog__sidebar">
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Search</h2>
                                <form action="#" class="blog__search">
                                    <input type="text" placeholder="Search">
                                    <button type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                            <path d="M17 17L13.5247 13.5247M15.681 8.3405C15.681 12.3945 12.3945 15.681 8.3405 15.681C4.28645 15.681 1 12.3945 1 8.3405C1 4.28645 4.28645 1 8.3405 1C12.3945 1 15.681 4.28645 15.681 8.3405Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </button>
                                </form>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Recent Posts</h2>
                                <div class="rc-post-wrap">
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img01.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img02.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img03.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img04.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Categories</h2>
                                <div class="bs-cat-list">
                                    <ul class="list-wrap">
                                        <li><a href="blog.php">Business Strategy <span>(02)</span></a></li>
                                        <li><a href="blog.php">Finance Advisory <span>(08)</span></a></li>
                                        <li><a href="blog.php">Marketing Analysis <span>(05)</span></a></li>
                                        <li><a href="blog.php">Investment Planning <span>(02)</span></a></li>
                                        <li><a href="blog.php">Data Analysis <span>(11)</span></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Popular Tags</h2>
                                <div class="sidebar__tag-list">
                                    <ul class="list-wrap">
                                        <li><a href="blog.php">Finance</a></li>
                                        <li><a href="blog.php">Investment</a></li>
                                        <li><a href="blog.php">TAX</a></li>
                                        <li><a href="blog.php">Banking</a></li>
                                        <li><a href="blog.php">Finance Advisor</a></li>
                                        <li><a href="blog.php">Tax Consultancy</a></li>
                                        <li><a href="blog.php">Security</a></li>
                                    </ul>
                                </div>
                            </div>
                             <div class="sidebar__widget sidebar__widget-bg sidebar__widget-bg-two" data-background="assets/img/bg/sidebar_bg.jpg">
                                <div class="sidebar__contact">
                                    <h2 class="title">Reach out to us whenever you need</h2>
                                    <p>We are committed to excellence at our IT solutions company.</p>
                                    <div class="cta__contact">
                                        <div class="icon">
                                            <svg width="53" height="53" viewBox="0 0 53 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M40.1629 32.3041C39.1215 31.2685 37.8655 30.7148 36.5343 30.7148C35.2138 30.7148 33.947 31.2583 32.8627 32.2939L29.4703 35.5239C29.1911 35.3803 28.912 35.247 28.6436 35.1137C28.2572 34.9291 27.8922 34.7548 27.5808 34.5702C24.4031 32.6425 21.5152 30.1303 18.7455 26.8799C17.4035 25.2597 16.5017 23.896 15.8469 22.5117C16.7272 21.7427 17.5431 20.9429 18.3375 20.1738C18.6381 19.8867 18.9387 19.5894 19.2393 19.3023C21.4938 17.149 21.4938 14.3599 19.2393 12.2066L16.3085 9.4073C15.9757 9.08943 15.6322 8.7613 15.3101 8.43318C14.666 7.79744 13.9896 7.14119 13.2918 6.52596C12.2505 5.54159 11.0052 5.01865 9.69542 5.01865C8.38569 5.01865 7.11889 5.54159 6.04534 6.52596C6.0346 6.53622 6.0346 6.53622 6.02387 6.54647L2.37379 10.0635C0.999637 11.376 0.215944 12.9756 0.0441751 14.8316C-0.213478 17.8257 0.709778 20.6148 1.41832 22.4399C3.15748 26.9209 5.75548 31.0737 9.63101 35.5239C14.3332 40.8866 19.9908 45.1215 26.4536 48.1053C28.9228 49.223 32.2186 50.5457 35.9009 50.7713C36.1263 50.7816 36.3625 50.7918 36.5772 50.7918C39.0571 50.7918 41.1398 49.9408 42.7716 48.2489C42.7823 48.2284 42.8038 48.2181 42.8145 48.1976C43.3728 47.5516 44.0169 46.9671 44.6933 46.3417C45.1549 45.9213 45.6273 45.4803 46.0889 45.0189C47.1517 43.9628 47.7099 42.7323 47.7099 41.4711C47.7099 40.1996 47.141 38.9794 46.0567 37.954L40.1629 32.3041ZM44.0062 43.1014C43.9954 43.1117 43.9954 43.1014 44.0062 43.1014C43.5875 43.5321 43.1581 43.9218 42.6964 44.3524C41.9986 44.9882 41.2901 45.6547 40.6245 46.4032C39.5402 47.5106 38.2627 48.0335 36.5879 48.0335C36.4269 48.0335 36.2551 48.0336 36.0941 48.0233C32.9056 47.8285 29.9426 46.639 27.7204 45.6239C21.6441 42.8143 16.3085 38.8256 11.8747 33.7704C8.21392 29.5561 5.76621 25.6596 4.14515 21.4761C3.14674 18.9229 2.78174 16.9336 2.94277 15.0572C3.05012 13.8575 3.53322 12.8628 4.42427 12.0118L8.08509 8.51521C8.61113 8.04353 9.16938 7.78719 9.71689 7.78719C10.3932 7.78719 10.9407 8.17683 11.2843 8.50496C11.295 8.51521 11.3057 8.52546 11.3165 8.53572C11.9714 9.12019 12.594 9.72516 13.2489 10.3712C13.5817 10.6993 13.9252 11.0274 14.2688 11.3658L17.1996 14.1651C18.3375 15.252 18.3375 16.2569 17.1996 17.3438C16.8882 17.6411 16.5876 17.9385 16.2763 18.2256C15.3745 19.1074 14.5157 19.9277 13.5817 20.7275C13.5602 20.7481 13.5387 20.7583 13.528 20.7788C12.6047 21.6606 12.7765 22.522 12.9698 23.1064C12.9805 23.1372 12.9912 23.168 13.002 23.1987C13.7642 24.9624 14.8377 26.6235 16.4695 28.6025L16.4803 28.6128C19.4433 32.0991 22.5673 34.8163 26.0134 36.8979C26.4536 37.1645 26.9045 37.3798 27.3339 37.5849C27.7204 37.7694 28.0854 37.9438 28.3967 38.1283C28.4397 38.1488 28.4826 38.1796 28.5255 38.2001C28.8906 38.3744 29.2341 38.4565 29.5884 38.4565C30.4794 38.4565 31.0377 37.9233 31.2202 37.7489L34.8917 34.2421C35.2567 33.8935 35.8364 33.4731 36.5128 33.4731C37.1784 33.4731 37.7259 33.873 38.0587 34.2216C38.0694 34.2319 38.0694 34.2319 38.0802 34.2421L43.9955 39.892C45.1012 40.9379 45.1012 42.0145 44.0062 43.1014Z" fill="currentColor" />
                                                <path d="M27.452 13.7652C30.2647 14.2164 32.8198 15.4878 34.8595 17.4361C36.8993 19.3843 38.2197 21.8247 38.7028 24.5112C38.8209 25.188 39.4328 25.6596 40.1307 25.6596C40.2165 25.6596 40.2917 25.6494 40.3776 25.6391C41.172 25.5161 41.698 24.7983 41.5692 24.0395C40.9895 20.7891 39.3792 17.8257 36.9207 15.4776C34.4623 13.1294 31.3597 11.5914 27.9566 11.0377C27.1621 10.9146 26.4214 11.4171 26.2818 12.1656C26.1423 12.9141 26.6576 13.6421 27.452 13.7652Z" fill="currentColor" />
                                                <path d="M50.7696 23.6396C49.8141 18.2871 47.1732 13.4166 43.1151 9.5406C39.0571 5.66464 33.9577 3.14219 28.3538 2.2296C27.5701 2.0963 26.8293 2.60899 26.6898 3.35752C26.5609 4.11631 27.087 4.82382 27.8814 4.95712C32.8842 5.76718 37.4468 8.03328 41.0754 11.4888C44.704 14.9546 47.0658 19.3125 47.9139 24.0908C48.032 24.7676 48.6439 25.2392 49.3417 25.2392C49.4276 25.2392 49.5028 25.229 49.5887 25.2187C50.3724 25.1059 50.9091 24.3882 50.7696 23.6396Z" fill="currentColor" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <span>Call For More Info</span>
                                            <a href="tel: +971 552783479">+971 552783479</a>
                                        </div>
                                    </div>
                                    <a href="contact.php" class="tg-btn">Contact With Us
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </section>
        <!-- blog-post-area-end -->

<?php
	include_once ('elements/footer.php')
?>