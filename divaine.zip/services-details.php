<?php
	include_once ('elements/header.php')
?>
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg fix" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h2 class="title">Data & Analytics</h2>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="index.php">Home</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="services.php">Services</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">Data & Analytics</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- services-details-area -->
        <section class="services__details-area section-py-120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 order-0 order-lg-2">
                        <div class="services__details-wrap">
                            <div class="services__details-thumb">
                                <img src="assets/img/blog/blog_img01.jpg" alt="img">
                            </div>
                            <div class="services__details-content">
                                <h2 class="title">Transforming Complex Data into Engaging Visual Insights</h2>
                                <p class="text-bold">Each demo built with Teba will look different. You can customize almost anything ce offer your website with only a few clicks Each demo built with Teba will exceptional opportunities with interdependent users.</p>
                                <p>Each demo built with Teba will look different. You can customize almost anything in the appearance offer your website with only a few clicks  Each demo built with Teba will look differentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                <ul class="choose__list choose__list-three list-wrap">
                                    <li>
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        tiveinvolves asseyour Creating and editing content current
                                    </li>
                                    <li>
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Flexibility, scalability, and performance and analysis
                                    </li>
                                    <li>
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        AI-Powered Operations
                                    </li>
                                    <li>
                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Multilingual content capabilities
                                    </li>
                                </ul>
                                <h2 class="title-two">Our Service Benefits</h2>
                                <p>Each demo built with Teba will look different. You can customize almost anything in the appearance offer your website with only a few clicks  Each demo built with Teba will look differentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                <div class="services__details-inner">
                                    <div class="thumb">
                                        <img src="assets/img/images/services_details.jpg" alt="img">
                                    </div>
                                    <div class="services__details-inner-item-wrap">
                                        <div class="services__details-inner-item">
                                            <div class="icon">
                                                <i class="flaticon-profit-margin"></i>
                                            </div>
                                            <div class="content">
                                                <h2 class="title">Analysis And <br> Planning</h2>
                                                <p>transforma tiveinvo asseyour current financial situat tally.</p>
                                            </div>
                                        </div>
                                        <div class="services__details-inner-item">
                                            <div class="icon">
                                                <i class="flaticon-test"></i>
                                            </div>
                                            <div class="content">
                                                <h2 class="title">Testing & Quality <br> Assurance</h2>
                                                <p>transforma tiveinvo asseyour current financial situat tally.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="faq__wrap">
                                <h2 class="title">Have You Any Question?</h2>
                                <div class="accordion" id="accordionExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What is business marketing and why is it important?
                                        </button>
                                        </h2>
                                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>Each demo built with Teba will look different. You can customize almost appearance offer website with only a few clicks  Each deerentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            Do I need a business plan?
                                        </button>
                                        </h2>
                                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>Each demo built with Teba will look different. You can customize almost appearance offer website with only a few clicks  Each deerentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            Empowering Business Through Innovation
                                        </button>
                                        </h2>
                                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>Each demo built with Teba will look different. You can customize almost appearance offer website with only a few clicks  Each deerentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            How to Soft Launch Your Business?
                                        </button>
                                        </h2>
                                        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>Each demo built with Teba will look different. You can customize almost appearance offer website with only a few clicks  Each deerentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            How Can I Find My Solution?
                                        </button>
                                        </h2>
                                        <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <p>Each demo built with Teba will look different. You can customize almost appearance offer website with only a few clicks  Each deerentUniquely syndicate exceptional opportunities with interdependent users. </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <aside class="services__sidebar">
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Quick Services</h2>
                                <div class="sidebar__cat-list">
                                    <ul class="list-wrap">
                                        <li>
                                            <a href="services-details.php">IT Consulting & Strategy
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services-details.php">Data & Analytics
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services-details.php">Cyber Security Solutions
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services-details.php">IT Management System
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services-details.php">Mobile Apps Development
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="services-details.php">AI & Automation Solutions
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 13L13 1M13 1H1M13 1V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="sidebar__widget sidebar__widget-bg" data-background="assets/img/bg/sidebar_bg.jpg">
                                <div class="sidebar__contact">
                                    <h2 class="title">Reach out to us whenever you need</h2>
                                    <p>We are committed to excellence at our IT solutions company.</p>
                                    <div class="cta__contact">
                                        <div class="icon">
                                            <svg width="53" height="53" viewBox="0 0 53 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M40.1629 32.3041C39.1215 31.2685 37.8655 30.7148 36.5343 30.7148C35.2138 30.7148 33.947 31.2583 32.8627 32.2939L29.4703 35.5239C29.1911 35.3803 28.912 35.247 28.6436 35.1137C28.2572 34.9291 27.8922 34.7548 27.5808 34.5702C24.4031 32.6425 21.5152 30.1303 18.7455 26.8799C17.4035 25.2597 16.5017 23.896 15.8469 22.5117C16.7272 21.7427 17.5431 20.9429 18.3375 20.1738C18.6381 19.8867 18.9387 19.5894 19.2393 19.3023C21.4938 17.149 21.4938 14.3599 19.2393 12.2066L16.3085 9.4073C15.9757 9.08943 15.6322 8.7613 15.3101 8.43318C14.666 7.79744 13.9896 7.14119 13.2918 6.52596C12.2505 5.54159 11.0052 5.01865 9.69542 5.01865C8.38569 5.01865 7.11889 5.54159 6.04534 6.52596C6.0346 6.53622 6.0346 6.53622 6.02387 6.54647L2.37379 10.0635C0.999637 11.376 0.215944 12.9756 0.0441751 14.8316C-0.213478 17.8257 0.709778 20.6148 1.41832 22.4399C3.15748 26.9209 5.75548 31.0737 9.63101 35.5239C14.3332 40.8866 19.9908 45.1215 26.4536 48.1053C28.9228 49.223 32.2186 50.5457 35.9009 50.7713C36.1263 50.7816 36.3625 50.7918 36.5772 50.7918C39.0571 50.7918 41.1398 49.9408 42.7716 48.2489C42.7823 48.2284 42.8038 48.2181 42.8145 48.1976C43.3728 47.5516 44.0169 46.9671 44.6933 46.3417C45.1549 45.9213 45.6273 45.4803 46.0889 45.0189C47.1517 43.9628 47.7099 42.7323 47.7099 41.4711C47.7099 40.1996 47.141 38.9794 46.0567 37.954L40.1629 32.3041ZM44.0062 43.1014C43.9954 43.1117 43.9954 43.1014 44.0062 43.1014C43.5875 43.5321 43.1581 43.9218 42.6964 44.3524C41.9986 44.9882 41.2901 45.6547 40.6245 46.4032C39.5402 47.5106 38.2627 48.0335 36.5879 48.0335C36.4269 48.0335 36.2551 48.0336 36.0941 48.0233C32.9056 47.8285 29.9426 46.639 27.7204 45.6239C21.6441 42.8143 16.3085 38.8256 11.8747 33.7704C8.21392 29.5561 5.76621 25.6596 4.14515 21.4761C3.14674 18.9229 2.78174 16.9336 2.94277 15.0572C3.05012 13.8575 3.53322 12.8628 4.42427 12.0118L8.08509 8.51521C8.61113 8.04353 9.16938 7.78719 9.71689 7.78719C10.3932 7.78719 10.9407 8.17683 11.2843 8.50496C11.295 8.51521 11.3057 8.52546 11.3165 8.53572C11.9714 9.12019 12.594 9.72516 13.2489 10.3712C13.5817 10.6993 13.9252 11.0274 14.2688 11.3658L17.1996 14.1651C18.3375 15.252 18.3375 16.2569 17.1996 17.3438C16.8882 17.6411 16.5876 17.9385 16.2763 18.2256C15.3745 19.1074 14.5157 19.9277 13.5817 20.7275C13.5602 20.7481 13.5387 20.7583 13.528 20.7788C12.6047 21.6606 12.7765 22.522 12.9698 23.1064C12.9805 23.1372 12.9912 23.168 13.002 23.1987C13.7642 24.9624 14.8377 26.6235 16.4695 28.6025L16.4803 28.6128C19.4433 32.0991 22.5673 34.8163 26.0134 36.8979C26.4536 37.1645 26.9045 37.3798 27.3339 37.5849C27.7204 37.7694 28.0854 37.9438 28.3967 38.1283C28.4397 38.1488 28.4826 38.1796 28.5255 38.2001C28.8906 38.3744 29.2341 38.4565 29.5884 38.4565C30.4794 38.4565 31.0377 37.9233 31.2202 37.7489L34.8917 34.2421C35.2567 33.8935 35.8364 33.4731 36.5128 33.4731C37.1784 33.4731 37.7259 33.873 38.0587 34.2216C38.0694 34.2319 38.0694 34.2319 38.0802 34.2421L43.9955 39.892C45.1012 40.9379 45.1012 42.0145 44.0062 43.1014Z" fill="currentColor" />
                                                <path d="M27.452 13.7652C30.2647 14.2164 32.8198 15.4878 34.8595 17.4361C36.8993 19.3843 38.2197 21.8247 38.7028 24.5112C38.8209 25.188 39.4328 25.6596 40.1307 25.6596C40.2165 25.6596 40.2917 25.6494 40.3776 25.6391C41.172 25.5161 41.698 24.7983 41.5692 24.0395C40.9895 20.7891 39.3792 17.8257 36.9207 15.4776C34.4623 13.1294 31.3597 11.5914 27.9566 11.0377C27.1621 10.9146 26.4214 11.4171 26.2818 12.1656C26.1423 12.9141 26.6576 13.6421 27.452 13.7652Z" fill="currentColor" />
                                                <path d="M50.7696 23.6396C49.8141 18.2871 47.1732 13.4166 43.1151 9.5406C39.0571 5.66464 33.9577 3.14219 28.3538 2.2296C27.5701 2.0963 26.8293 2.60899 26.6898 3.35752C26.5609 4.11631 27.087 4.82382 27.8814 4.95712C32.8842 5.76718 37.4468 8.03328 41.0754 11.4888C44.704 14.9546 47.0658 19.3125 47.9139 24.0908C48.032 24.7676 48.6439 25.2392 49.3417 25.2392C49.4276 25.2392 49.5028 25.229 49.5887 25.2187C50.3724 25.1059 50.9091 24.3882 50.7696 23.6396Z" fill="currentColor" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <span>Call For More Info</span>
                                            <a href="tel: +971 552783479">+971 552783479</a>
                                        </div>
                                    </div>
                                    <a href="contact.php" class="tg-btn">Contact With Us
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Download</h2>
                                <div class="sidebar__brochure">
                                    <a href="assets/img/project/project_img10.jpg" target="_blank" download>
                                        <span class="icon">
                                            <svg width="18" height="24" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 21V6.75L11.25 0H3C2.20435 0 1.44129 0.316071 0.87868 0.87868C0.31607 1.44129 0 2.20435 0 3V21C0 21.7957 0.31607 22.5587 0.87868 23.1213C1.44129 23.6839 2.20435 24 3 24H15C15.7957 24 16.5587 23.6839 17.1213 23.1213C17.6839 22.5587 18 21.7957 18 21ZM11.25 4.5C11.25 5.09674 11.4871 5.66903 11.909 6.09099C12.331 6.51295 12.9033 6.75 13.5 6.75H16.5V21C16.5 21.3978 16.342 21.7794 16.0607 22.0607C15.7794 22.342 15.3978 22.5 15 22.5H3C2.60218 22.5 2.22064 22.342 1.93934 22.0607C1.65804 21.7794 1.5 21.3978 1.5 21V3C1.5 2.60218 1.65804 2.22064 1.93934 1.93934C2.22064 1.65804 2.60218 1.5 3 1.5H11.25V4.5Z" fill="currentColor" />
                                                <path d="M3.9045 21.1305C3.61214 21.0136 3.37659 20.7877 3.2475 20.5005C2.955 19.9185 3.0525 19.3365 3.3675 18.8475C3.6645 18.387 4.1565 17.9955 4.713 17.667C5.41791 17.2672 6.16303 16.9429 6.936 16.6995C7.53629 15.6204 8.06833 14.5047 8.529 13.359C8.25357 12.7332 8.03762 12.0828 7.884 11.4165C7.755 10.8165 7.7055 10.2225 7.815 9.7125C7.9275 9.1815 8.226 8.7045 8.79 8.478C9.078 8.3625 9.39 8.298 9.693 8.3625C9.84542 8.39495 9.9887 8.46091 10.1125 8.55561C10.2362 8.65031 10.3373 8.77137 10.4085 8.91C10.5405 9.156 10.5885 9.444 10.599 9.717C10.6095 9.999 10.581 10.311 10.5285 10.638C10.4025 11.403 10.1235 12.339 9.7485 13.329C10.1623 14.214 10.6543 15.0604 11.2185 15.858C11.8862 15.8053 12.5577 15.8304 13.2195 15.933C13.7655 16.032 14.3205 16.2255 14.6595 16.6305C14.8395 16.8465 14.949 17.1105 14.9595 17.4075C14.97 17.6955 14.889 17.9805 14.7525 18.252C14.6343 18.5036 14.4509 18.719 14.2215 18.876C13.9947 19.0239 13.7269 19.0964 13.4565 19.083C12.96 19.062 12.4755 18.789 12.057 18.4575C11.5481 18.0367 11.0896 17.5586 10.6905 17.0325C9.67613 17.1476 8.6738 17.3514 7.695 17.6415C7.24677 18.4364 6.73511 19.1939 6.165 19.9065C5.727 20.4315 5.2515 20.8905 4.7745 21.087C4.50043 21.211 4.18957 21.2265 3.9045 21.1305ZM5.973 18.279C5.724 18.393 5.493 18.513 5.2845 18.636C4.7925 18.927 4.473 19.2105 4.314 19.4565C4.173 19.674 4.17 19.8315 4.254 19.998C4.269 20.031 4.284 20.052 4.293 20.064C4.3109 20.0592 4.32844 20.0532 4.3455 20.046C4.551 19.962 4.878 19.6935 5.298 19.188C5.53687 18.8955 5.76211 18.5922 5.973 18.279ZM8.433 16.284C8.93389 16.1671 9.4393 16.0705 9.948 15.9945C9.67488 15.5765 9.41965 15.1471 9.183 14.7075C8.94773 15.2394 8.69763 15.7646 8.433 16.2825V16.284ZM12.102 16.959C12.327 17.2035 12.546 17.409 12.7545 17.574C13.1145 17.859 13.365 17.9535 13.5015 17.958C13.538 17.9628 13.5751 17.9548 13.6065 17.9355C13.6689 17.8862 13.7175 17.8216 13.7475 17.748C13.8008 17.6566 13.8312 17.5537 13.836 17.448C13.8351 17.4128 13.8212 17.3791 13.797 17.3535C13.719 17.2605 13.497 17.1255 13.02 17.04C12.7166 16.9893 12.4096 16.9627 12.102 16.9605V16.959ZM9.117 11.7C9.24324 11.2928 9.34344 10.8779 9.417 10.458C9.4635 10.176 9.4815 9.9435 9.474 9.7605C9.47441 9.65954 9.4582 9.55919 9.426 9.4635C9.35096 9.47279 9.27769 9.493 9.2085 9.5235C9.078 9.576 8.9715 9.6825 8.9145 9.948C8.8545 10.236 8.8695 10.6515 8.9835 11.181C9.0195 11.3475 9.0645 11.5215 9.1185 11.7H9.117Z" fill="currentColor" />
                                            </svg>
                                        </span>
                                        <span class="content">
                                            <strong>PDF. Download</strong>
                                            <svg width="25" height="21" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8.50018 15.0117L12.5002 19.0117M12.5002 19.0117L16.5002 15.0117M12.5002 19.0117V10.0117M21.3802 16.1017C22.2496 15.4903 22.9015 14.6178 23.2415 13.6108C23.5814 12.6038 23.5916 11.5147 23.2706 10.5015C22.9496 9.48828 22.314 8.60374 21.4562 7.97621C20.5985 7.34868 19.563 7.01082 18.5002 7.01165H17.2402C16.9394 5.83952 16.3767 4.7509 15.5943 3.82773C14.8119 2.90456 13.8303 2.17091 12.7234 1.68201C11.6164 1.1931 10.413 0.961679 9.2037 1.00517C7.99439 1.04866 6.81069 1.36592 5.74173 1.93308C4.67277 2.50023 3.7464 3.3025 3.03236 4.27948C2.31833 5.25646 1.83523 6.3827 1.61944 7.5734C1.40365 8.7641 1.46079 9.98825 1.78656 11.1537C2.11233 12.3191 2.69824 13.3954 3.50018 14.3017" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </span>
                                    </a>
                                    <a href="assets/img/project/project_img10.jpg" target="_blank" download>
                                        <span class="icon">
                                            <svg width="18" height="24" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M18 21V6.75L11.25 0H3C2.20435 0 1.44129 0.316071 0.87868 0.87868C0.31607 1.44129 0 2.20435 0 3V21C0 21.7957 0.31607 22.5587 0.87868 23.1213C1.44129 23.6839 2.20435 24 3 24H15C15.7957 24 16.5587 23.6839 17.1213 23.1213C17.6839 22.5587 18 21.7957 18 21ZM11.25 4.5C11.25 5.09674 11.4871 5.66903 11.909 6.09099C12.331 6.51295 12.9033 6.75 13.5 6.75H16.5V21C16.5 21.3978 16.342 21.7794 16.0607 22.0607C15.7794 22.342 15.3978 22.5 15 22.5H3C2.60218 22.5 2.22064 22.342 1.93934 22.0607C1.65804 21.7794 1.5 21.3978 1.5 21V3C1.5 2.60218 1.65804 2.22064 1.93934 1.93934C2.22064 1.65804 2.60218 1.5 3 1.5H11.25V4.5Z" fill="currentColor" />
                                                <path d="M3.9045 21.1305C3.61214 21.0136 3.37659 20.7877 3.2475 20.5005C2.955 19.9185 3.0525 19.3365 3.3675 18.8475C3.6645 18.387 4.1565 17.9955 4.713 17.667C5.41791 17.2672 6.16303 16.9429 6.936 16.6995C7.53629 15.6204 8.06833 14.5047 8.529 13.359C8.25357 12.7332 8.03762 12.0828 7.884 11.4165C7.755 10.8165 7.7055 10.2225 7.815 9.7125C7.9275 9.1815 8.226 8.7045 8.79 8.478C9.078 8.3625 9.39 8.298 9.693 8.3625C9.84542 8.39495 9.9887 8.46091 10.1125 8.55561C10.2362 8.65031 10.3373 8.77137 10.4085 8.91C10.5405 9.156 10.5885 9.444 10.599 9.717C10.6095 9.999 10.581 10.311 10.5285 10.638C10.4025 11.403 10.1235 12.339 9.7485 13.329C10.1623 14.214 10.6543 15.0604 11.2185 15.858C11.8862 15.8053 12.5577 15.8304 13.2195 15.933C13.7655 16.032 14.3205 16.2255 14.6595 16.6305C14.8395 16.8465 14.949 17.1105 14.9595 17.4075C14.97 17.6955 14.889 17.9805 14.7525 18.252C14.6343 18.5036 14.4509 18.719 14.2215 18.876C13.9947 19.0239 13.7269 19.0964 13.4565 19.083C12.96 19.062 12.4755 18.789 12.057 18.4575C11.5481 18.0367 11.0896 17.5586 10.6905 17.0325C9.67613 17.1476 8.6738 17.3514 7.695 17.6415C7.24677 18.4364 6.73511 19.1939 6.165 19.9065C5.727 20.4315 5.2515 20.8905 4.7745 21.087C4.50043 21.211 4.18957 21.2265 3.9045 21.1305ZM5.973 18.279C5.724 18.393 5.493 18.513 5.2845 18.636C4.7925 18.927 4.473 19.2105 4.314 19.4565C4.173 19.674 4.17 19.8315 4.254 19.998C4.269 20.031 4.284 20.052 4.293 20.064C4.3109 20.0592 4.32844 20.0532 4.3455 20.046C4.551 19.962 4.878 19.6935 5.298 19.188C5.53687 18.8955 5.76211 18.5922 5.973 18.279ZM8.433 16.284C8.93389 16.1671 9.4393 16.0705 9.948 15.9945C9.67488 15.5765 9.41965 15.1471 9.183 14.7075C8.94773 15.2394 8.69763 15.7646 8.433 16.2825V16.284ZM12.102 16.959C12.327 17.2035 12.546 17.409 12.7545 17.574C13.1145 17.859 13.365 17.9535 13.5015 17.958C13.538 17.9628 13.5751 17.9548 13.6065 17.9355C13.6689 17.8862 13.7175 17.8216 13.7475 17.748C13.8008 17.6566 13.8312 17.5537 13.836 17.448C13.8351 17.4128 13.8212 17.3791 13.797 17.3535C13.719 17.2605 13.497 17.1255 13.02 17.04C12.7166 16.9893 12.4096 16.9627 12.102 16.9605V16.959ZM9.117 11.7C9.24324 11.2928 9.34344 10.8779 9.417 10.458C9.4635 10.176 9.4815 9.9435 9.474 9.7605C9.47441 9.65954 9.4582 9.55919 9.426 9.4635C9.35096 9.47279 9.27769 9.493 9.2085 9.5235C9.078 9.576 8.9715 9.6825 8.9145 9.948C8.8545 10.236 8.8695 10.6515 8.9835 11.181C9.0195 11.3475 9.0645 11.5215 9.1185 11.7H9.117Z" fill="currentColor" />
                                            </svg>
                                        </span>
                                        <span class="content">
                                            <strong>Company Details</strong>
                                            <svg width="25" height="21" viewBox="0 0 25 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8.50018 15.0117L12.5002 19.0117M12.5002 19.0117L16.5002 15.0117M12.5002 19.0117V10.0117M21.3802 16.1017C22.2496 15.4903 22.9015 14.6178 23.2415 13.6108C23.5814 12.6038 23.5916 11.5147 23.2706 10.5015C22.9496 9.48828 22.314 8.60374 21.4562 7.97621C20.5985 7.34868 19.563 7.01082 18.5002 7.01165H17.2402C16.9394 5.83952 16.3767 4.7509 15.5943 3.82773C14.8119 2.90456 13.8303 2.17091 12.7234 1.68201C11.6164 1.1931 10.413 0.961679 9.2037 1.00517C7.99439 1.04866 6.81069 1.36592 5.74173 1.93308C4.67277 2.50023 3.7464 3.3025 3.03236 4.27948C2.31833 5.25646 1.83523 6.3827 1.61944 7.5734C1.40365 8.7641 1.46079 9.98825 1.78656 11.1537C2.11233 12.3191 2.69824 13.3954 3.50018 14.3017" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </section>
        <!-- services-details-area-end -->

        <!-- cta-area -->
        <section class="cta__area-two">
            <div class="cta__bg" data-background="assets/img/slider/slider_bg02.jpg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-5 col-lg-6">
                        <div class="cta__content-four">
                            <div class="section__title white-title mb-10">
                                <h2 class="title">Empowering IT Businesses One Step at a Time</h2>
                            </div>
                            <p>transforma Support team tiveinvolve asseyour current ancial gize grantsbvisualize strategic ediarey.</p>
                            <div class="cta__content-bottom">
                                <a href="contact.php" class="tg-btn white-btn">Make An Appointment
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                                <div class="cta__contact">
                                    <div class="icon">
                                        <svg width="53" height="53" viewBox="0 0 53 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M40.1629 32.3041C39.1215 31.2685 37.8655 30.7148 36.5343 30.7148C35.2138 30.7148 33.947 31.2583 32.8627 32.2939L29.4703 35.5239C29.1911 35.3803 28.912 35.247 28.6436 35.1137C28.2572 34.9291 27.8922 34.7548 27.5808 34.5702C24.4031 32.6425 21.5152 30.1303 18.7455 26.8799C17.4035 25.2597 16.5017 23.896 15.8469 22.5117C16.7272 21.7427 17.5431 20.9429 18.3375 20.1738C18.6381 19.8867 18.9387 19.5894 19.2393 19.3023C21.4938 17.149 21.4938 14.3599 19.2393 12.2066L16.3085 9.4073C15.9757 9.08943 15.6322 8.7613 15.3101 8.43318C14.666 7.79744 13.9896 7.14119 13.2918 6.52596C12.2505 5.54159 11.0052 5.01865 9.69542 5.01865C8.38569 5.01865 7.11889 5.54159 6.04534 6.52596C6.0346 6.53622 6.0346 6.53622 6.02387 6.54647L2.37379 10.0635C0.999637 11.376 0.215944 12.9756 0.0441751 14.8316C-0.213478 17.8257 0.709778 20.6148 1.41832 22.4399C3.15748 26.9209 5.75548 31.0737 9.63101 35.5239C14.3332 40.8866 19.9908 45.1215 26.4536 48.1053C28.9228 49.223 32.2186 50.5457 35.9009 50.7713C36.1263 50.7816 36.3625 50.7918 36.5772 50.7918C39.0571 50.7918 41.1398 49.9408 42.7716 48.2489C42.7823 48.2284 42.8038 48.2181 42.8145 48.1976C43.3728 47.5516 44.0169 46.9671 44.6933 46.3417C45.1549 45.9213 45.6273 45.4803 46.0889 45.0189C47.1517 43.9628 47.7099 42.7323 47.7099 41.4711C47.7099 40.1996 47.141 38.9794 46.0567 37.954L40.1629 32.3041ZM44.0062 43.1014C43.9954 43.1117 43.9954 43.1014 44.0062 43.1014C43.5875 43.5321 43.1581 43.9218 42.6964 44.3524C41.9986 44.9882 41.2901 45.6547 40.6245 46.4032C39.5402 47.5106 38.2627 48.0335 36.5879 48.0335C36.4269 48.0335 36.2551 48.0336 36.0941 48.0233C32.9056 47.8285 29.9426 46.639 27.7204 45.6239C21.6441 42.8143 16.3085 38.8256 11.8747 33.7704C8.21392 29.5561 5.76621 25.6596 4.14515 21.4761C3.14674 18.9229 2.78174 16.9336 2.94277 15.0572C3.05012 13.8575 3.53322 12.8628 4.42427 12.0118L8.08509 8.51521C8.61113 8.04353 9.16938 7.78719 9.71689 7.78719C10.3932 7.78719 10.9407 8.17683 11.2843 8.50496C11.295 8.51521 11.3057 8.52546 11.3165 8.53572C11.9714 9.12019 12.594 9.72516 13.2489 10.3712C13.5817 10.6993 13.9252 11.0274 14.2688 11.3658L17.1996 14.1651C18.3375 15.252 18.3375 16.2569 17.1996 17.3438C16.8882 17.6411 16.5876 17.9385 16.2763 18.2256C15.3745 19.1074 14.5157 19.9277 13.5817 20.7275C13.5602 20.7481 13.5387 20.7583 13.528 20.7788C12.6047 21.6606 12.7765 22.522 12.9698 23.1064C12.9805 23.1372 12.9912 23.168 13.002 23.1987C13.7642 24.9624 14.8377 26.6235 16.4695 28.6025L16.4803 28.6128C19.4433 32.0991 22.5673 34.8163 26.0134 36.8979C26.4536 37.1645 26.9045 37.3798 27.3339 37.5849C27.7204 37.7694 28.0854 37.9438 28.3967 38.1283C28.4397 38.1488 28.4826 38.1796 28.5255 38.2001C28.8906 38.3744 29.2341 38.4565 29.5884 38.4565C30.4794 38.4565 31.0377 37.9233 31.2202 37.7489L34.8917 34.2421C35.2567 33.8935 35.8364 33.4731 36.5128 33.4731C37.1784 33.4731 37.7259 33.873 38.0587 34.2216C38.0694 34.2319 38.0694 34.2319 38.0802 34.2421L43.9955 39.892C45.1012 40.9379 45.1012 42.0145 44.0062 43.1014Z" fill="currentColor" />
                                            <path d="M27.452 13.7652C30.2647 14.2164 32.8198 15.4878 34.8595 17.4361C36.8993 19.3843 38.2197 21.8247 38.7028 24.5112C38.8209 25.188 39.4328 25.6596 40.1307 25.6596C40.2165 25.6596 40.2917 25.6494 40.3776 25.6391C41.172 25.5161 41.698 24.7983 41.5692 24.0395C40.9895 20.7891 39.3792 17.8257 36.9207 15.4776C34.4623 13.1294 31.3597 11.5914 27.9566 11.0377C27.1621 10.9146 26.4214 11.4171 26.2818 12.1656C26.1423 12.9141 26.6576 13.6421 27.452 13.7652Z" fill="currentColor" />
                                            <path d="M50.7696 23.6396C49.8141 18.2871 47.1732 13.4166 43.1151 9.5406C39.0571 5.66464 33.9577 3.14219 28.3538 2.2296C27.5701 2.0963 26.8293 2.60899 26.6898 3.35752C26.5609 4.11631 27.087 4.82382 27.8814 4.95712C32.8842 5.76718 37.4468 8.03328 41.0754 11.4888C44.704 14.9546 47.0658 19.3125 47.9139 24.0908C48.032 24.7676 48.6439 25.2392 49.3417 25.2392C49.4276 25.2392 49.5028 25.229 49.5887 25.2187C50.3724 25.1059 50.9091 24.3882 50.7696 23.6396Z" fill="currentColor" />
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <span>Call For More Info</span>
                                        <a href="tel: +971 552783479">+971 552783479</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- cta-area-end -->
<?php
	include_once ('elements/footer.php')
?>