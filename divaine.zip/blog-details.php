<?php
	include_once ('elements/header.php')
?>
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg fix" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h2 class="title">Blog Details</h2>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="index.php">Home</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">Blog Details</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- blog-post-area -->
        <section class="blog-post__area-four section-py-140">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog__details-wrap">
                            <div class="blog-post__thumb-five blog__details-thumb">
                                <img src="assets/img/blog/blog_img01.jpg" alt="img">
                            </div>
                            <div class="blog__details-content blog-post__content-five">
                                <ul class="blog-post__meta blog-post__meta-three list-wrap">
                                    <li>12 Sep, 2025</li>
                                    <li>by <a href="blog-details.php">Michel Richard</a></li>
                                </ul>
                                <h2 class="post-title">Get a few solutions to hire a best candidate</h2>
                                <p>Eed a little help from our friends from time to time. Although we offer the one-stop convenience of annery integrated range of legal, financial services under one roof, there are occasions when our clients areaneed specia- list advice beyond.</p>
                                <p>For dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vestibulum lorem sed risus ultricies tristique nulla. Sem viverra aliquet eget sit amet tellus cras adipiscing. Varius sit amet mattis vulputate enim nulla.</p>
                                <blockquote>
                                    <p>“ Modern lifeblood of mobile phones and tablets toda The true potential your mob phone  tions  can provide utility. Apps come under variousof mobile. ”</p>
                                    <cite>Elon Musk, CO Founder</cite>
                                </blockquote>
                                <p>For dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vestibulum lorem sed risus ultricies tristique nulla. Sem viverra aliquet eget sit amet tellus cras adipiscing. Varius sit amet mattis vulputate enim nulla.</p>
                                <div class="blog__details-inner">
                                    <div class="row align-items-center">
                                        <div class="col-46 order-0 order-lg-2">
                                            <div class="blog__details-inner-thumb">
                                                <img src="assets/img/blog/blog_img05.jpg" alt="img">
                                                <a href="https://www.youtube.com/watch?v=6mkoGSqTqFI" class="play-btn popup-video video__icon">
                                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M15.5 8.1341C16.1667 8.519 16.1667 9.48125 15.5 9.86615L2 17.6604C1.33333 18.0453 0.499999 17.5642 0.499999 16.7944L0.5 1.20589C0.5 0.436092 1.33333 -0.0450328 2 0.339867L15.5 8.1341Z" fill="currentColor"></path>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-54">
                                            <div class="blog__details-inner-content">
                                                <h2 class="title">Conduct replied off whether arrived adapted</h2>
                                                <p>when an unknown printer took a galley type remaining essentially unchan galley of type and scrambled it to make a type specimen book.</p>
                                                <ul class="choose__list choose__list-three list-wrap">
                                                    <li>
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                        tiveinvolves asseyour current
                                                    </li>
                                                    <li>
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                        Innovate freely, bring ideas alive
                                                    </li>
                                                    <li>
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                        AI-Powered Operations
                                                    </li>
                                                    <li>
                                                        <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                            <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                        Access Control Management
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <h2 class="title-two">modern Business Possibility</h2>
                                <p>When an unknown printer took a galley  type remaining essentially unchan galley of type and scrambled it to make a type specimen book.hole planet, providing a health threat to many countries. As a result, it is critical to give it equal weight. With escalating levels of dynamic disaster risk coming from social polarization, rapidly rising poverty levels.</p>
                                <div class="blog__details-bottom">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <div class="post-tags">
                                                <h2 class="title">Post Tags:</h2>
                                                <ul class="list-wrap">
                                                    <li><a href="blog.php">Business</a></li>
                                                    <li><a href="blog.php">Agency Theme</a></li>
                                                    <li><a href="blog.php">Marketing Team</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-5">
                                            <div class="post-share">
                                                <h2 class="title">Social Share:</h2>
                                                <ul class="list-wrap">
                                                    <li>
                                                        <a href="https://www.facebook.com/" target="_blank">
                                                            <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                                            </svg>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://x.com/" target="_blank">
                                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                                            </svg>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.instagram.com/" target="_blank">
                                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                                            </svg>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.pinterest.com/" target="_blank">
                                                            <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                                            </svg>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="blog__avatar-wrap mb-60">
                                <div class="blog__avatar-img">
                                    <a href="#"><img src="assets/img/images/testi_avatar01.jpg" alt="img"></a>
                                </div>
                                <div class="blog__avatar-info">
                                    <span class="designation">Author</span>
                                    <h2 class="name"><a href="#">Parker Willy</a></h2>
                                    <p>Finanappreciate your trust greatly Our clients choose dentace ducts because know we are the best area Awaitingare really.</p>
                                </div>
                            </div>
                            <div class="comments-wrap">
                                <h3 class="comments-wrap-title">02 Comments</h3>
                                <div class="latest-comments">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="comments-box">
                                                <div class="comments-avatar">
                                                    <img src="assets/img/images/testi_avatar02.jpg" alt="img">
                                                </div>
                                                <div class="comments-text">
                                                    <div class="avatar-name">
                                                        <h2 class="name">Jessica Rose</h2>
                                                        <span class="date">December 27, 2025</span>
                                                    </div>
                                                    <p>Finanappreciate your trust greatly Our clients choose dentace ducts because know we are the best area Awaitingare really.</p>
                                                    <a href="#" class="reply-btn">Reply</a>
                                                </div>
                                            </div>
                                            <ul class="children">
                                                <li>
                                                    <div class="comments-box">
                                                        <div class="comments-avatar">
                                                            <img src="assets/img/images/testi_avatar03.jpg" alt="img">
                                                        </div>
                                                        <div class="comments-text">
                                                            <div class="avatar-name">
                                                                <h2 class="name">Parker Willy</h2>
                                                                <span class="date">December 28, 2025</span>
                                                            </div>
                                                            <p>Finanappreciate your trust greatly Our clients choose dentace ducts because know we are the best area Awaitingare really.</p>
                                                            <a href="#" class="reply-btn">Reply</a>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="comment-respond">
                                <h3 class="comment-reply-title">Post a comment</h3>
                                <form action="#" class="comment-form">
                                    <p class="comment-notes">Your email address will not be published. Required fields are marked *</p>
                                    <div class="form-grp">
                                        <textarea name="comment" placeholder="Comment"></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-grp">
                                                <input type="text" placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-grp">
                                                <input type="email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-grp">
                                                <input type="url" placeholder="Website">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-grp checkbox-grp">
                                        <input type="checkbox" id="checkbox">
                                        <label for="checkbox">Save my name, email, and website in this browser for the next time I comment.</label>
                                    </div>
                                    <button type="submit" class="tg-btn tg-btn-three">Submit Comment</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <aside class="blog__sidebar">
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Search</h2>
                                <form action="#" class="blog__search">
                                    <input type="text" placeholder="Search">
                                    <button type="submit">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                            <path d="M17 17L13.5247 13.5247M15.681 8.3405C15.681 12.3945 12.3945 15.681 8.3405 15.681C4.28645 15.681 1 12.3945 1 8.3405C1 4.28645 4.28645 1 8.3405 1C12.3945 1 15.681 4.28645 15.681 8.3405Z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </button>
                                </form>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Recent Posts</h2>
                                <div class="rc-post-wrap">
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img01.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img02.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img03.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                    <div class="rc-post-item">
                                        <div class="thumb">
                                            <a href="blog-details.php"><img src="assets/img/project/project_img04.jpg" alt=""></a>
                                        </div>
                                        <div class="content">
                                            <span class="date">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.1111 2V4.80003M5.88888 2V4.80003M2 7.59992H16M3.55556 3.39988H14.4444C15.3036 3.39988 16 4.02668 16 4.79989V14.6C16 15.3732 15.3036 16 14.4444 16H3.55556C2.69645 16 2 15.3732 2 14.6V4.79989C2 4.02668 2.69645 3.39988 3.55556 3.39988Z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                                Oct 21, 2025
                                            </span>
                                            <h2 class="post-title"><a href="blog-details.php">Business prospectus for an easy</a></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Categories</h2>
                                <div class="bs-cat-list">
                                    <ul class="list-wrap">
                                        <li><a href="blog.php">Business Strategy <span>(02)</span></a></li>
                                        <li><a href="blog.php">Finance Advisory <span>(08)</span></a></li>
                                        <li><a href="blog.php">Marketing Analysis <span>(05)</span></a></li>
                                        <li><a href="blog.php">Investment Planning <span>(02)</span></a></li>
                                        <li><a href="blog.php">Data Analysis <span>(11)</span></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="sidebar__widget">
                                <h2 class="widget__title">Popular Tags</h2>
                                <div class="sidebar__tag-list">
                                    <ul class="list-wrap">
                                        <li><a href="blog.php">Finance</a></li>
                                        <li><a href="blog.php">Investment</a></li>
                                        <li><a href="blog.php">TAX</a></li>
                                        <li><a href="blog.php">Banking</a></li>
                                        <li><a href="blog.php">Finance Advisor</a></li>
                                        <li><a href="blog.php">Tax Consultancy</a></li>
                                        <li><a href="blog.php">Security</a></li>
                                    </ul>
                                </div>
                            </div>
                             <div class="sidebar__widget sidebar__widget-bg sidebar__widget-bg-two" data-background="assets/img/bg/sidebar_bg.jpg">
                                <div class="sidebar__contact">
                                    <h2 class="title">Reach out to us whenever you need</h2>
                                    <p>We are committed to excellence at our IT solutions company.</p>
                                    <div class="cta__contact">
                                        <div class="icon">
                                            <svg width="53" height="53" viewBox="0 0 53 53" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M40.1629 32.3041C39.1215 31.2685 37.8655 30.7148 36.5343 30.7148C35.2138 30.7148 33.947 31.2583 32.8627 32.2939L29.4703 35.5239C29.1911 35.3803 28.912 35.247 28.6436 35.1137C28.2572 34.9291 27.8922 34.7548 27.5808 34.5702C24.4031 32.6425 21.5152 30.1303 18.7455 26.8799C17.4035 25.2597 16.5017 23.896 15.8469 22.5117C16.7272 21.7427 17.5431 20.9429 18.3375 20.1738C18.6381 19.8867 18.9387 19.5894 19.2393 19.3023C21.4938 17.149 21.4938 14.3599 19.2393 12.2066L16.3085 9.4073C15.9757 9.08943 15.6322 8.7613 15.3101 8.43318C14.666 7.79744 13.9896 7.14119 13.2918 6.52596C12.2505 5.54159 11.0052 5.01865 9.69542 5.01865C8.38569 5.01865 7.11889 5.54159 6.04534 6.52596C6.0346 6.53622 6.0346 6.53622 6.02387 6.54647L2.37379 10.0635C0.999637 11.376 0.215944 12.9756 0.0441751 14.8316C-0.213478 17.8257 0.709778 20.6148 1.41832 22.4399C3.15748 26.9209 5.75548 31.0737 9.63101 35.5239C14.3332 40.8866 19.9908 45.1215 26.4536 48.1053C28.9228 49.223 32.2186 50.5457 35.9009 50.7713C36.1263 50.7816 36.3625 50.7918 36.5772 50.7918C39.0571 50.7918 41.1398 49.9408 42.7716 48.2489C42.7823 48.2284 42.8038 48.2181 42.8145 48.1976C43.3728 47.5516 44.0169 46.9671 44.6933 46.3417C45.1549 45.9213 45.6273 45.4803 46.0889 45.0189C47.1517 43.9628 47.7099 42.7323 47.7099 41.4711C47.7099 40.1996 47.141 38.9794 46.0567 37.954L40.1629 32.3041ZM44.0062 43.1014C43.9954 43.1117 43.9954 43.1014 44.0062 43.1014C43.5875 43.5321 43.1581 43.9218 42.6964 44.3524C41.9986 44.9882 41.2901 45.6547 40.6245 46.4032C39.5402 47.5106 38.2627 48.0335 36.5879 48.0335C36.4269 48.0335 36.2551 48.0336 36.0941 48.0233C32.9056 47.8285 29.9426 46.639 27.7204 45.6239C21.6441 42.8143 16.3085 38.8256 11.8747 33.7704C8.21392 29.5561 5.76621 25.6596 4.14515 21.4761C3.14674 18.9229 2.78174 16.9336 2.94277 15.0572C3.05012 13.8575 3.53322 12.8628 4.42427 12.0118L8.08509 8.51521C8.61113 8.04353 9.16938 7.78719 9.71689 7.78719C10.3932 7.78719 10.9407 8.17683 11.2843 8.50496C11.295 8.51521 11.3057 8.52546 11.3165 8.53572C11.9714 9.12019 12.594 9.72516 13.2489 10.3712C13.5817 10.6993 13.9252 11.0274 14.2688 11.3658L17.1996 14.1651C18.3375 15.252 18.3375 16.2569 17.1996 17.3438C16.8882 17.6411 16.5876 17.9385 16.2763 18.2256C15.3745 19.1074 14.5157 19.9277 13.5817 20.7275C13.5602 20.7481 13.5387 20.7583 13.528 20.7788C12.6047 21.6606 12.7765 22.522 12.9698 23.1064C12.9805 23.1372 12.9912 23.168 13.002 23.1987C13.7642 24.9624 14.8377 26.6235 16.4695 28.6025L16.4803 28.6128C19.4433 32.0991 22.5673 34.8163 26.0134 36.8979C26.4536 37.1645 26.9045 37.3798 27.3339 37.5849C27.7204 37.7694 28.0854 37.9438 28.3967 38.1283C28.4397 38.1488 28.4826 38.1796 28.5255 38.2001C28.8906 38.3744 29.2341 38.4565 29.5884 38.4565C30.4794 38.4565 31.0377 37.9233 31.2202 37.7489L34.8917 34.2421C35.2567 33.8935 35.8364 33.4731 36.5128 33.4731C37.1784 33.4731 37.7259 33.873 38.0587 34.2216C38.0694 34.2319 38.0694 34.2319 38.0802 34.2421L43.9955 39.892C45.1012 40.9379 45.1012 42.0145 44.0062 43.1014Z" fill="currentColor" />
                                                <path d="M27.452 13.7652C30.2647 14.2164 32.8198 15.4878 34.8595 17.4361C36.8993 19.3843 38.2197 21.8247 38.7028 24.5112C38.8209 25.188 39.4328 25.6596 40.1307 25.6596C40.2165 25.6596 40.2917 25.6494 40.3776 25.6391C41.172 25.5161 41.698 24.7983 41.5692 24.0395C40.9895 20.7891 39.3792 17.8257 36.9207 15.4776C34.4623 13.1294 31.3597 11.5914 27.9566 11.0377C27.1621 10.9146 26.4214 11.4171 26.2818 12.1656C26.1423 12.9141 26.6576 13.6421 27.452 13.7652Z" fill="currentColor" />
                                                <path d="M50.7696 23.6396C49.8141 18.2871 47.1732 13.4166 43.1151 9.5406C39.0571 5.66464 33.9577 3.14219 28.3538 2.2296C27.5701 2.0963 26.8293 2.60899 26.6898 3.35752C26.5609 4.11631 27.087 4.82382 27.8814 4.95712C32.8842 5.76718 37.4468 8.03328 41.0754 11.4888C44.704 14.9546 47.0658 19.3125 47.9139 24.0908C48.032 24.7676 48.6439 25.2392 49.3417 25.2392C49.4276 25.2392 49.5028 25.229 49.5887 25.2187C50.3724 25.1059 50.9091 24.3882 50.7696 23.6396Z" fill="currentColor" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <span>Call For More Info</span>
                                            <a href="tel: +971 552783479">+971 552783479</a>
                                        </div>
                                    </div>
                                    <a href="contact.php" class="tg-btn">Contact With Us
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </section>
        <!-- blog-post-area-end -->

<?php
	include_once ('elements/footer.php')
?>