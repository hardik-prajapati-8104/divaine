

<?php
	include_once ('elements/header.php')
?>
 
        <!-- slider-area -->
        <section class="slider__area fix">
            <div class="swiper-container slider__active" id="heroSlider" data-swiper-options='{
                "loop": true,
                "effect": "fade",
                "autoplay": { "delay": 4000 },
                "breakpoints": {
                    "0": { "spaceBetween": 0, "slidesPerView": 1 },
                    "375": { "spaceBetween": 0, "slidesPerView": 1 },
                    "575": { "spaceBetween": 0, "slidesPerView": 1 },
                    "768": { "spaceBetween": 0, "slidesPerView": 1 },
                    "992": { "spaceBetween": 0, "slidesPerView": 1 },
                    "1400": { "spaceBetween": 0, "slidesPerView": 1 }
                },
                "pagination": {
                    "el": ".slider-pagination",
                    "clickable": true
                }}'>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slider__bg">
                            <div class="slider__bg-img" data-background="assets/img/slider/slider_bg01.jpg"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-5 col-lg-6">
                                        <div class="slider__content">
                                            <span class="sub-title">professional IT services</span>
                                            <h2 class="title">Delivering The Best Tech It Solutions For Startups</h2>
                                            <p>Professionally optimize interdependent intellectual interop erable connectbest practi Progressively.</p>
                                            <div class="slider__btn">
                                                <a href="about.php" class="tg-btn">Read More
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                                <a href="services.php" class="tg-btn white-btn">See All Services
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slider__shape">
                                <img src="assets/img/slider/slider_shape.svg" alt="shape">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider__bg">
                            <div class="slider__bg-img" data-background="assets/img/slider/slider_bg02.jpg"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-5 col-lg-6">
                                        <div class="slider__content">
                                            <span class="sub-title">professional IT services</span>
                                            <h2 class="title">Empowering the Future with Robotic Solutions</h2>
                                            <p>Professionally optimize interdependent intellectual interop erable connectbest practi Progressively.</p>
                                            <div class="slider__btn">
                                                <a href="about.php" class="tg-btn">Read More
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                                <a href="services.php" class="tg-btn white-btn">See All Services
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slider__shape">
                                <img src="assets/img/slider/slider_shape.svg" alt="shape">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider__bg">
                            <div class="slider__bg-img" data-background="assets/img/slider/slider_bg03.jpg"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-5 col-lg-6">
                                        <div class="slider__content">
                                            <span class="sub-title">professional IT services</span>
                                            <h2 class="title">Comprehensive Solutions & data protection</h2>
                                            <p>Professionally optimize interdependent intellectual interop erable connectbest practi Progressively.</p>
                                            <div class="slider__btn">
                                                <a href="about.php" class="tg-btn">Read More
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                                <a href="services.php" class="tg-btn white-btn">See All Services
                                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                        <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slider__shape">
                                <img src="assets/img/slider/slider_shape.svg" alt="shape">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="slider-pagination"></div>
        </section>
        <!-- slider-area-end -->

        <!-- brand-area -->
        <div class="brand__area fix">
            <div class="brand__active swiper-container fix" id="brandSlider" data-swiper-options='{
                "loop": true,
                "autoplay": { "delay": 2000 },
                "breakpoints": {
                    "0": {
                        "spaceBetween": 10,
                        "slidesPerView": 2
                    },
                    "375": {
                        "spaceBetween": 20,
                        "slidesPerView": 2
                    },
                    "575": {
                        "spaceBetween": 20,
                        "slidesPerView": 3
                    },
                    "768": {
                        "spaceBetween": 10,
                        "slidesPerView": 4
                    },
                    "992": {
                        "spaceBetween": 20,
                        "slidesPerView": 6
                    },
                    "1200": {
                        "spaceBetween": 20,
                        "slidesPerView": 7
                    },
                    "1400": {
                        "spaceBetween": 20,
                        "slidesPerView": 9
                    }
                }}'>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_01.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_02.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_03.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_04.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_05.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_06.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_07.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_08.png" alt="img">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="brand__item">
                            <img src="assets/img/brand/brand_09.png" alt="img">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand-area-end -->

        <!-- about-area -->
        <section class="about__area section-pt-140 section-pb-110 fix">
            <div class="container">
                <div class="row align-items-end justify-content-center">
                    <div class="col-lg-4 col-md-8 order-0 order-lg-2">
                        <div class="about__img" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                            <img src="assets/img/images/about_img.jpg" alt="img" class="main-img">
                            <div class="experience__wrap">
                                <h2 class="count">25 <span>+</span></h2>
                                <span class="text">Years of <br> Experience</span>
                            </div>
                            <img src="assets/img/images/about_shape.svg" alt="shape" class="shape rotateme">
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="about__content">
                            <div class="section__title mb-15">
                                <span class="sub-title">About Our Company</span>
                                <h2 class="title">We provide Best perfect it solutions for startups Company</h2>
                            </div>
                            <p>Transform your business with our transformative aIt is a long established fact that a reader will be distracted the readable content of a page when looking at layout the point of using lorem the is Ipsum less normal distribution of letters.reatyclting.</p>
                            <div class="about__content-inner">
                                <div class="about__content-video" data-sal="slide-right" data-sal-duration="700" data-sal-delay="100">
                                    <img src="assets/img/images/video_img.jpg" alt="img">
                                    <a href="https://www.youtube.com/watch?v=6mkoGSqTqFI" class="popup-video video__icon">
                                        <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15.5 8.1341C16.1667 8.519 16.1667 9.48125 15.5 9.86615L2 17.6604C1.33333 18.0453 0.499999 17.5642 0.499999 16.7944L0.5 1.20589C0.5 0.436092 1.33333 -0.0450328 2 0.339867L15.5 8.1341Z" fill="currentColor" />
                                        </svg>
                                    </a>
                                </div>
                                <div class="about__list-wrap" data-sal="slide-left" data-sal-duration="700" data-sal-delay="100">
                                    <div class="about__list-item">
                                        <div class="icon">
                                            <i class="flaticon-inspiration"></i>
                                        </div>
                                        <div class="content">
                                            <h2 class="title">Innovative IT Solutions</h2>
                                            <p>Transform your busisformative lished fact that a reader.</p>
                                        </div>
                                    </div>
                                    <div class="about__list-item">
                                        <div class="icon">
                                            <i class="flaticon-settings"></i>
                                        </div>
                                        <div class="content">
                                            <h2 class="title">Digital Transformation</h2>
                                            <p>busisformative ransform your lished fact that a reader.</p>
                                        </div>
                                    </div>
                                    <a href="contact.php" class="tg-btn black-btn">Contact With Us
                                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-area-end -->

        <!-- counter-area -->
        <section class="counter__area section-pb-140 fix">
            <div class="container">
                <div class="counter__item-wrap">
                    <div class="row gutter-y-40">
                        <div class="col-lg-4 col-md-4 col-6">
                            <div class="counter__item">
                                <h2 class="count"><span class="counter-number">80</span>%</h2>
                                <p>Business Success</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-6">
                            <div class="counter__item">
                                <h2 class="count"><span class="counter-number">90</span>%</h2>
                                <p>Project Handover</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-6">
                            <div class="counter__item">
                                <h2 class="count"><span class="counter-number">88</span>%</h2>
                                <p>Happy Clients</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- counter-area-end -->

        <!-- services-area -->
        <section class="services__area section-bg section-py-140 fix">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-lg-6">
                        <div class="section__title text-center mb-45" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                            <span class="sub-title">About Our Company</span>
                            <h2 class="title">Innovative Our It Solutions And Services</h2>
                        </div>
                    </div>
                </div>
                <div class="row gutter-y-30">
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-it-service"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">IT Consulting & Strategy</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="200">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-data-access"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">Data & Analytics Services</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="300">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-internet-security"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">Cyber Security Solutions</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-technical-support"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">Modern IT Management System</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="200">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-coding"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">Web & Mobile Apps Development</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6" data-sal="slide-up" data-sal-duration="700" data-sal-delay="300">
                        <div class="services__item">
                            <div class="services__icon-wrap">
                                <div class="services__icon">
                                    <i class="flaticon-technology"></i>
                                </div>
                            </div>
                            <div class="services__content">
                                <h2 class="title"><a href="services-details.php">AI & Automation Solutions</a></h2>
                                <p>transforma tiveinvolves asseyour current financial situat tally synergize grantsb visualize strategic ediarey.</p>
                                <a href="services-details.php" class="tg-text-btn">Read More
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="services__shape">
                <img src="assets/img/images/services_shape.svg" alt="shape" class="alltuchtopdown">
            </div>
        </section>
        <!-- services-area-end -->

        <!-- choose-area -->
        <section class="choose__area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8">
                        <div class="choose__inner-wrap">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <div class="choose__content">
                                        <div class="section__title white-title mb-15">
                                            <span class="sub-title">Why Choose US</span>
                                            <h2 class="title">Delivering Custom IT Solutions Services</h2>
                                        </div>
                                        <p>transforma tiveinvolve asseyour current ancial gize grantsbvisualize strategic ediarey.</p>
                                        <a href="about.php" class="tg-btn white-btn">See More Details
                                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <ul class="choose__list list-wrap">
                                        <li>
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            tiveinvolves asseyour current
                                        </li>
                                        <li>
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            Innovate freely, bring ideas alive
                                        </li>
                                        <li>
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            AI-Powered Operations
                                        </li>
                                        <li>
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M29.9142 11.0033C30.4204 12.8928 28.5305 14.9239 28.2895 16.7482C28.0392 18.6401 29.31 21.0892 28.372 22.7197C27.434 24.35 24.6725 24.4711 23.1593 25.6339C21.7009 26.7586 20.8849 29.4083 18.9964 29.9144C17.108 30.4204 15.0765 28.5295 13.251 28.2886C11.3592 28.0384 8.91003 29.3092 7.27958 28.3713C5.64914 27.4332 5.52798 24.6719 4.36627 23.1584C3.24138 21.7001 0.592009 20.885 0.0857368 18.9957C-0.420555 17.1063 1.47056 15.0757 1.71164 13.2514C1.96094 11.3598 0.690114 8.91071 1.62814 7.2803C2.56617 5.6499 5.32758 5.52875 6.84086 4.3661C8.30021 3.24097 9.1152 0.591668 11.0037 0.0856724C12.8922 -0.420342 14.9247 1.47019 16.7491 1.71127C18.641 1.96154 21.0903 0.69075 22.7206 1.62875C24.3511 2.56676 24.4722 5.3281 25.6349 6.84134C26.7545 8.29583 29.4068 9.11001 29.9142 11.0033Z" fill="currentColor" />
                                                <path d="M20.8182 10.5L12.8182 18.5L9.18182 14.8636" stroke="white" stroke-width="2.18182" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                            tiveinvolves asse your current
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose__img" data-background="assets/img/slider/slider_bg03.jpg"></div>
            <div class="choose__shape">
                <img src="assets/img/images/choose_shape.png" alt="shape">
            </div>
        </section>
        <!-- choose-area-end -->

        <!-- counter-area -->
        <section class="counter__area-two">
            <div class="container">
                <div class="row gutter-y-30 justify-content-center">
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="counter__item-two">
                            <div class="counter__icon">
                                <svg width="98" height="77" viewBox="0 0 98 77" fill="#fff" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M97.4392 21.7506L75.7871 0.549116C75.0559 -0.167508 73.8746 -0.185075 73.1217 0.51032C71.4401 2.06142 63.5364 9.34843 63.422 9.4575C63.4153 9.46409 63.4078 9.46994 63.4011 9.47653C61.5289 11.3094 59.6858 12.1264 57.4249 12.1264C52.8027 12.1264 49.2617 13.4044 46.3211 16.1311C43.9098 13.8956 41.177 12.7398 37.3631 12.354L27.7943 2.9852C27.0466 2.2532 25.8346 2.2532 25.0869 2.9852L0.560769 26.9976C-0.167472 27.7098 -0.191398 28.8605 0.518151 29.602C0.533104 29.6174 0.545815 29.6328 0.560769 29.6474C0.560769 29.6474 16.5208 45.2484 16.5432 45.2696L15.8673 45.9314C13.2504 48.4934 13.2489 52.6423 15.868 55.2065C17.1077 56.4187 18.8109 57.139 20.6741 57.1207C20.6539 58.9206 21.3642 60.5874 22.6353 61.8318C23.9265 63.0959 25.6522 63.7664 27.4414 63.7481C27.4219 65.5467 28.1315 67.2127 29.4025 68.4571C30.6422 69.6693 32.3447 70.3895 34.2086 70.3712C34.1884 72.1712 34.8987 73.838 36.1698 75.0824C38.7815 77.6392 43.0305 77.6392 45.6429 75.0824L46.3203 74.4192L46.9977 75.0824C49.6094 77.6392 53.8584 77.6392 56.4708 75.0824C57.7389 73.8409 58.4507 72.1771 58.4327 70.3749C60.2608 70.3932 61.964 69.7044 63.2388 68.4563C64.5622 67.1607 65.2142 65.453 65.1963 63.7511C67.052 63.7701 68.7477 63.063 70.0053 61.8318C71.2786 60.5859 71.9874 58.9162 71.9665 57.1207C73.7452 57.1382 75.4746 56.4765 76.7733 55.2058C79.391 52.643 79.391 48.4948 76.7733 45.9314L76.0982 45.2704C89.4435 32.2196 72.5617 48.7605 97.4392 24.4005C98.1869 23.6685 98.1869 22.4826 97.4392 21.7506ZM4.62142 28.3218L26.441 6.96066L33.7944 14.1598L11.9793 35.5202L4.62142 28.3218ZM18.5739 52.5559C17.4524 51.4579 17.4524 49.6799 18.5739 48.5812L25.3419 41.9552C26.4619 40.8594 28.2825 40.8601 29.4018 41.9552C30.5256 43.0561 30.5256 44.8312 29.4018 45.9314L22.636 52.5552C21.516 53.6503 19.6932 53.6503 18.5739 52.5559ZM25.3419 59.182C24.2196 58.0825 24.2181 56.3052 25.3419 55.2058L32.1084 48.5812C33.2322 47.4817 35.046 47.481 36.1698 48.5812C37.2891 49.677 37.2936 51.4557 36.1698 52.5552C36.1691 52.5559 36.1691 52.5559 36.1691 52.5567L29.4018 59.182C28.2825 60.2777 26.4612 60.2777 25.3419 59.182ZM32.1084 65.8058C30.9869 64.7085 30.9869 62.9298 32.1084 61.8318L38.8764 55.2058C39.9957 54.11 41.8163 54.11 42.9371 55.2072C44.0421 56.2869 44.075 58.0657 42.9363 59.1812C42.9363 59.1812 42.9363 59.1812 42.9356 59.182L36.1706 65.805C35.0505 66.9008 33.2277 66.9008 32.1084 65.8058ZM38.8764 72.4325C37.7541 71.3331 37.7526 69.5558 38.8764 68.4563L45.6429 61.8318C46.7652 60.7331 48.5806 60.7316 49.7036 61.8318C50.8333 62.9378 50.8169 64.7173 49.7036 65.8065L42.9363 72.4325C41.8163 73.5276 39.9957 73.5276 38.8764 72.4325ZM53.7635 72.4325C52.6449 73.5283 50.8236 73.5283 49.7043 72.4325L49.0269 71.7693L52.4109 68.4563C52.6397 68.2323 52.8461 67.993 53.0375 67.7448L53.7627 68.4556C53.7635 68.4556 53.7635 68.4556 53.7642 68.4563L53.765 68.4571C54.8872 69.5558 54.8872 71.3323 53.7635 72.4325ZM74.0667 52.5552C72.9467 53.6503 71.1246 53.6503 70.0053 52.5552L61.2081 43.9433C60.4604 43.2113 59.2485 43.2113 58.5008 43.9433C57.7538 44.6745 57.7538 45.8611 58.5008 46.5931L67.2987 55.2065C68.421 56.3045 68.4217 58.0818 67.298 59.182C66.1742 60.2821 64.3581 60.2777 63.2388 59.182L54.4416 50.5671C53.6947 49.8358 52.4827 49.8358 51.735 50.5671C50.9873 51.2991 50.9873 52.4857 51.7343 53.2177L60.5315 61.8318C61.6508 62.9276 61.6508 64.7107 60.5315 65.8058C59.9902 66.3365 59.2686 66.6293 58.5008 66.6293C56.6817 66.6293 56.0955 65.2268 54.3706 63.7503C54.3534 62.0243 53.6595 60.4044 52.4117 59.1827C51.1421 57.9383 49.4419 57.2436 47.6048 57.2612C47.6235 55.4598 46.911 53.7952 45.6429 52.5552C44.3195 51.2596 42.5752 50.622 40.8368 50.6396C40.875 46.9437 37.8177 43.9733 34.0703 44.0113C34.089 42.1909 33.3623 40.5329 32.1084 39.3053C29.4968 36.7478 25.2469 36.7478 22.6353 39.3053L19.2498 42.6198L14.6889 38.1678L37.2166 16.1091C40.0062 16.421 41.8843 17.2064 43.6062 18.7736L38.1983 24.0674C35.2158 26.9895 35.2158 31.7446 38.199 34.6682C41.1845 37.5888 46.0422 37.5896 49.0269 34.6674L54.4416 29.367C57.9408 32.7935 71.5156 46.0844 74.066 48.5819C75.1853 49.677 75.1853 51.4601 74.0667 52.5552ZM73.3908 42.6198L57.1482 26.7172L58.5015 25.3923C59.2492 24.6603 59.2492 23.4737 58.5015 22.7418C57.7538 22.0105 56.5426 22.0105 55.7942 22.7418L46.3196 32.0183C44.8279 33.4787 42.398 33.4787 40.9056 32.0183C39.414 30.5565 39.414 28.1783 40.9049 26.7172C42.8683 24.7957 46.7383 21.0077 48.6994 19.0884C50.9694 16.866 53.661 15.8742 57.4249 15.8742C60.1322 15.8742 62.4695 15.0778 64.6594 13.3912L83.7185 32.5351C71.2599 44.7009 73.7191 42.2992 73.3908 42.6198ZM86.4259 29.8846L67.4842 10.8585L74.3942 4.48506L93.3793 23.0755L86.4259 29.8846Z" fill="#fff" />
                                </svg>
                            </div>
                            <div class="counter__content">
                                <h2 class="count"><span class="counter-number">25</span>K</h2>
                                <p>Project Completed</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="counter__item-two">
                            <div class="counter__icon">
                                <svg width="82" height="77" viewBox="0 0 82 77" fill="#fff" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M42.6016 62.5625C42.6016 63.4485 41.8846 64.1667 41 64.1667C40.1154 64.1667 39.3984 63.4485 39.3984 62.5625C39.3984 61.6764 40.1154 60.9583 41 60.9583C41.8846 60.9583 42.6016 61.6764 42.6016 62.5625Z" fill="currentColor" />
                                    <path d="M76.7149 48.125C76.7149 42.8175 72.4044 38.5 67.1055 38.5C61.8066 38.5 57.4961 42.8175 57.4961 48.125C57.4961 53.4325 61.8066 57.75 67.1055 57.75C72.4044 57.75 76.7149 53.4325 76.7149 48.125ZM67.1055 54.5417C63.5733 54.5417 60.6992 51.6629 60.6992 48.125C60.6992 44.5871 63.5733 41.7083 67.1055 41.7083C70.6377 41.7083 73.5117 44.5871 73.5117 48.125C73.5117 51.6629 70.6377 54.5417 67.1055 54.5417Z" fill="#fff" />
                                    <path d="M67.1055 57.75C63.0697 57.75 59.0451 59.4281 56.3037 62.1489C52.6952 57.3991 47.131 54.5417 41 54.5417C35.1286 54.5417 29.4393 57.2249 25.6969 62.1489C22.9549 59.4287 18.931 57.75 14.8945 57.75C6.82103 57.75 0 64.3615 0 72.1875V75.3958C0 76.2819 0.716949 77 1.60156 77H80.3984C81.2831 77 82 76.2819 82 75.3958V72.1875C82 64.3615 75.179 57.75 67.1055 57.75ZM3.20312 72.1875C3.20312 66.1004 8.5571 60.9583 14.8945 60.9583C18.3623 60.9583 21.8013 62.4973 23.9302 64.9437C22.5226 67.667 21.7812 70.7024 21.7812 73.7917H3.20312V72.1875ZM41 57.75C49.9118 57.75 57.0156 64.9926 57.0156 73.7917H24.9844C24.9844 64.8754 32.2333 57.75 41 57.75ZM78.7969 73.7917H60.2188C60.2188 70.7024 59.4774 67.667 58.0698 64.9437C60.1987 62.4973 63.6377 60.9583 67.1055 60.9583C73.4429 60.9583 78.7969 66.1004 78.7969 72.1875V73.7917Z" fill="#fff" />
                                    <path d="M24.5039 48.125C24.5039 42.8175 20.1935 38.5 14.8945 38.5C9.59561 38.5 5.28516 42.8175 5.28516 48.125C5.28516 53.4325 9.59561 57.75 14.8945 57.75C20.1935 57.75 24.5039 53.4325 24.5039 48.125ZM14.8945 54.5417C11.3623 54.5417 8.48828 51.6629 8.48828 48.125C8.48828 44.5871 11.3623 41.7083 14.8945 41.7083C18.4267 41.7083 21.3008 44.5871 21.3008 48.125C21.3008 51.6629 18.4267 54.5417 14.8945 54.5417Z" fill="#fff" />
                                    <path d="M53.8125 41.7083C53.8125 34.6318 48.065 28.875 41 28.875C33.935 28.875 28.1875 34.6318 28.1875 41.7083C28.1875 48.7848 33.935 54.5417 41 54.5417C48.065 54.5417 53.8125 48.7848 53.8125 41.7083ZM41 51.3333C35.7011 51.3333 31.3906 47.0159 31.3906 41.7083C31.3906 36.4008 35.7011 32.0833 41 32.0833C46.2989 32.0833 50.6094 36.4008 50.6094 41.7083C50.6094 47.0159 46.2989 51.3333 41 51.3333Z" fill="#fff" />
                                    <path d="M53.6748 9.32986C53.4865 8.74897 52.9854 8.326 52.3817 8.23827L45.4737 7.23379L42.3807 0.899837C42.1123 0.349032 41.5542 0 40.9424 0C40.3305 0 39.7725 0.349032 39.5035 0.899211L36.4111 7.23379L29.5031 8.23765C28.8994 8.32537 28.3983 8.74897 28.21 9.32986C28.0217 9.91074 28.1787 10.548 28.6154 10.9741L33.6177 15.8574L32.4372 22.7535C32.334 23.355 32.5811 23.9635 33.0747 24.3219C33.5652 24.6791 34.2183 24.7299 34.7614 24.4441L40.9424 21.1888L47.1259 24.4441C47.6652 24.7286 48.319 24.681 48.8126 24.3219C49.3056 23.9629 49.5527 23.355 49.4494 22.7528L48.2677 15.8574L53.2694 10.9741C53.7061 10.548 53.8631 9.91074 53.6748 9.32986ZM45.428 14.1486C45.0508 14.5171 44.8781 15.0485 44.9676 15.5686L45.7427 20.0922L41.6875 17.9566C41.2208 17.711 40.6634 17.711 40.1967 17.9566L36.1427 20.0922L36.9172 15.5686C37.0061 15.0478 36.8334 14.5171 36.4561 14.1486L33.1754 10.9459L37.708 10.2867C38.2323 10.2109 38.6846 9.88004 38.9167 9.4038L40.9424 5.25553L42.9675 9.4038C43.2002 9.88066 43.6525 10.2109 44.1762 10.2867L48.7093 10.9459L45.428 14.1486Z" fill="#fff" />
                                    <path d="M77.6132 21.353C77.4249 20.7721 76.9238 20.3491 76.3201 20.2614L71.6399 19.5802L69.5472 15.3317C69.2776 14.784 68.7214 14.4375 68.1114 14.4375C67.5021 14.4375 66.9447 14.784 66.675 15.3317L64.5811 19.5802L59.9003 20.2614C59.2972 20.3491 58.7961 20.7721 58.6078 21.353C58.4188 21.9338 58.5759 22.5711 59.0125 22.9972L62.399 26.3052L61.5994 30.9736C61.4968 31.5751 61.7433 32.183 62.2369 32.542C62.7299 32.9011 63.3837 32.9487 63.923 32.6648L68.1108 30.461L72.2974 32.6648C72.8367 32.9487 73.491 32.9011 73.984 32.542C74.477 32.1836 74.7235 31.5751 74.6209 30.9736L73.8214 26.3052L77.2084 22.9972C77.6451 22.5711 77.8015 21.9338 77.6132 21.353ZM70.983 24.597C70.6051 24.9655 70.4331 25.4962 70.5225 26.0163L70.9154 28.3123L68.8565 27.2288C68.3898 26.9832 67.8324 26.9832 67.3663 27.2288L65.3056 28.3129L65.6991 26.0163C65.7879 25.4962 65.6159 24.9655 65.2386 24.597L63.572 22.969L65.8749 22.6344C66.3966 22.5586 66.8477 22.2302 67.081 21.7571L68.1108 19.6673L69.1399 21.7565C69.3733 22.2302 69.8243 22.5586 70.3461 22.6344L72.649 22.969L70.983 24.597Z" fill="#fff" />
                                    <path d="M23.1601 21.353C22.9718 20.7721 22.4706 20.3491 21.8669 20.2614L17.1867 19.5802L15.0941 15.3317C14.8244 14.784 14.2683 14.4375 13.6583 14.4375C13.0483 14.4375 12.4915 14.784 12.2219 15.3317L10.128 19.5802L5.44715 20.2614C4.84407 20.3491 4.34295 20.7721 4.15464 21.353C3.96571 21.9338 4.12274 22.5711 4.55941 22.9972L7.94584 26.3052L7.14694 30.9736C7.04371 31.5751 7.29083 32.183 7.78381 32.542C8.27679 32.9011 8.93055 32.9487 9.47045 32.6648L13.6577 30.461L17.8442 32.6648C18.3873 32.9506 19.0404 32.8992 19.5309 32.542C20.0239 32.1836 20.271 31.5751 20.1678 30.9736L19.3682 26.3052L22.7553 22.9972C23.192 22.5711 23.3484 21.9338 23.1601 21.353ZM16.5292 24.597C16.152 24.9655 15.9799 25.4962 16.0688 26.0163L16.4623 28.3123L14.4028 27.2288C13.9367 26.9832 13.3793 26.9832 12.9132 27.2288L10.8518 28.3129L11.2453 26.0163C11.3348 25.4962 11.1621 24.9655 10.7849 24.597L9.11823 22.969L11.4217 22.6344C11.9429 22.5586 12.3939 22.2302 12.6273 21.7571L13.657 19.6673L14.6862 21.7565C14.9195 22.2302 15.3706 22.5586 15.8923 22.6344L18.1952 22.969L16.5292 24.597Z" fill="#fff" />
                                    <path d="M48.018 63.059C47.2786 62.5721 46.2857 62.7782 45.8002 63.5189C45.3141 64.259 45.52 65.2534 46.2594 65.7403C47.7403 66.7147 48.9239 68.0732 49.6822 69.6686C50.0613 70.4676 51.016 70.8091 51.8161 70.4275C52.615 70.0471 52.9541 69.0896 52.5744 68.2901C51.5646 66.1645 49.9887 64.3555 48.018 63.059Z" fill="#fff" />
                                </svg>
                            </div>
                            <div class="counter__content">
                                <h2 class="count"><span class="counter-number">98</span>K</h2>
                                <p>Satisfied Clients</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="counter__item-two">
                            <div class="counter__icon">
                                <svg width="84" height="84" viewBox="0 0 84 84" fill="#fff" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M58.724 45.9264C65.3904 45.731 71.6351 43.0401 76.3699 38.307C81.2903 33.3847 84 26.8422 84 19.8845C84 16.1573 80.9678 13.1251 77.2406 13.1251H66.6094V9.56154C68.5189 8.8843 69.8906 7.06074 69.8906 4.92187C69.8906 2.20795 67.6827 0 64.9688 0H48.5581C47.6521 0 46.9174 0.734507 46.9174 1.64062C46.9174 2.54674 47.6521 3.28124 48.5581 3.28124H64.9688C65.8734 3.28124 66.6094 4.01723 66.6094 4.92187C66.6094 5.8265 65.8734 6.56249 64.9688 6.56249H19.0312C18.1266 6.56249 17.3906 5.8265 17.3906 4.92187C17.3906 4.01723 18.1266 3.28124 19.0312 3.28124H35.4331C36.339 3.28124 37.0737 2.54674 37.0737 1.64062C37.0737 0.734507 36.339 0 35.4331 0H19.0312C16.3173 0 14.1094 2.20795 14.1094 4.92187C14.1094 7.06058 15.4811 8.8843 17.3906 9.56154V13.125H6.75938C4.95206 13.125 3.25451 13.8285 1.98089 15.1041C0.7035 16.3795 0 18.077 0 19.8845C0 26.8189 2.69374 33.3451 7.58494 38.2608C12.3245 43.0238 18.5855 45.7314 25.2761 45.9264C28.0311 48.4827 31.3697 50.417 35.0682 51.5045L30.9596 64.3125H30.5156C28.7063 64.3125 27.2344 65.7845 27.2344 67.5938V70.875H23.1328C21.3235 70.875 19.8516 72.347 19.8516 74.1563V80.7188C19.8516 82.528 21.3235 84 23.1328 84H60.8672C62.6765 84 64.1484 82.528 64.1484 80.7188V74.1563C64.1484 72.347 62.6765 70.875 60.8672 70.875H56.7656V67.5938C56.7656 65.7845 55.2937 64.3125 53.4844 64.3125H53.0404L48.9318 51.5045C52.6303 50.417 55.9691 48.4827 58.724 45.9264ZM77.2406 16.4064C79.1585 16.4064 80.7187 17.9666 80.7187 19.8845C80.7187 25.966 78.35 31.6847 74.0498 35.9869C70.7047 39.3308 66.497 41.5082 61.9295 42.3105C62.8356 41.0616 63.6272 39.7249 64.289 38.3152C67.7194 37.134 70.738 35.0266 73.0541 32.1875C75.5633 29.112 77.0574 25.4024 77.375 21.46C77.4117 21.0034 77.2559 20.5522 76.9455 20.2157C76.6347 19.8791 76.1977 19.6876 75.7396 19.6876H66.6094V16.4064H77.2406ZM66.6094 27.8907V22.9689H73.86C72.9437 27.6483 69.96 31.717 65.8324 34.0365C66.3397 32.0714 66.6094 30.0119 66.6094 27.8907ZM18.1676 34.0365C14.0401 31.717 11.0563 27.6483 10.14 22.9689H17.3906V27.8907C17.3906 30.0119 17.6605 32.0714 18.1676 34.0365ZM3.28125 19.8845C3.28125 18.9548 3.64268 18.0816 4.30123 17.4244C4.95666 16.7678 5.82963 16.4062 6.75938 16.4062H17.3906V19.6875H8.26055C7.80248 19.6875 7.36542 19.8789 7.05469 20.2156C6.74412 20.5522 6.58842 21.0034 6.62517 21.4598C6.9428 25.4021 8.43691 29.1117 10.9461 32.1874C13.2622 35.0265 16.2809 37.1338 19.7111 38.3151C20.372 39.7226 21.1621 41.0574 22.0666 42.3047C11.412 40.4093 3.28125 31.058 3.28125 19.8845ZM20.6719 27.8907V9.84389H63.3281V27.8907C63.3281 39.651 53.7605 49.2188 42 49.2188C30.2395 49.2188 20.6719 39.651 20.6719 27.8907ZM60.8693 80.7186H23.1328V74.1561H60.8672L60.8693 80.7186ZM53.4844 70.875H30.5156V67.5938H53.4844V70.875ZM49.5945 64.3125H34.4055L38.2846 52.2198C39.4966 52.4041 40.7374 52.5001 41.9998 52.5001C43.2625 52.5001 44.5031 52.4041 45.7152 52.2198L49.5945 64.3125Z" fill="#fff" />
                                    <path d="M47.9403 39.5385C48.149 39.6286 48.3703 39.6729 48.5905 39.6729C48.9316 39.6729 49.27 39.5666 49.555 39.3595C50.0237 39.0189 50.2782 38.4562 50.2241 37.8792L49.6206 31.4368L53.8956 26.5797C54.2785 26.1446 54.4036 25.5399 54.2244 24.9888C54.0452 24.4377 53.5887 24.022 53.0233 23.895L46.7098 22.4783L43.4115 16.9115C43.116 16.4129 42.5796 16.1073 41.9999 16.1073C41.4205 16.1073 40.8838 16.4129 40.5885 16.9115L37.29 22.4783L30.9767 23.895C30.4113 24.0218 29.9548 24.4377 29.7756 24.9888C29.5964 25.5399 29.7215 26.1446 30.1044 26.5797L34.3794 31.4368L33.7759 37.8792C33.7218 38.4562 33.9763 39.0189 34.445 39.3595C34.9141 39.7001 35.528 39.768 36.0597 39.5383L41.9999 36.9737L47.9403 39.5385ZM37.301 35.4286L37.7123 31.0378C37.7546 30.5878 37.6091 30.1402 37.3105 29.8007L34.3969 26.4905L38.6998 25.525C39.1408 25.4259 39.5216 25.1494 39.7521 24.7604L41.9999 20.9665L44.2479 24.7604C44.4784 25.1494 44.8592 25.4259 45.3002 25.525L49.6031 26.4905L46.6895 29.8007C46.3909 30.14 46.2454 30.5876 46.2877 31.0378L46.699 35.4286L42.6503 33.6805C42.4427 33.5909 42.2214 33.5461 41.9999 33.5461C41.7784 33.5461 41.5571 33.5909 41.3496 33.6805L37.301 35.4286Z" fill="#fff" />
                                    <path d="M42.0001 3.28125C42.9062 3.28125 43.6407 2.54672 43.6407 1.64063C43.6407 0.734533 42.9062 0 42.0001 0C41.094 0 40.3595 0.734533 40.3595 1.64063C40.3595 2.54672 41.094 3.28125 42.0001 3.28125Z" fill="#fff" />
                                </svg>
                            </div>
                            <div class="counter__content">
                                <h2 class="count"><span class="counter-number">80</span>K</h2>
                                <p>Company Award</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-6">
                        <div class="counter__item-two">
                            <div class="counter__icon">
                                <svg width="77" height="72" viewBox="0 0 77 72" fill="#fff" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M47.8242 60C46.9941 60 46.3203 60.6721 46.3203 61.5C46.3203 62.3279 46.9941 63 47.8242 63C48.6543 63 49.3281 62.3279 49.3281 61.5C49.3281 60.6721 48.6543 60 47.8242 60Z" fill="#fff" />
                                    <path d="M75.4961 69H73.6914V19.5C73.6914 18.6715 73.0182 18 72.1875 18H60.1562C59.3256 18 58.6523 18.6715 58.6523 19.5V69H55.3438V31.5C55.3438 30.6715 54.6705 30 53.8398 30H41.8086C40.9779 30 40.3047 30.6715 40.3047 31.5V69H36.9961V43.5C36.9961 42.6715 36.3229 42 35.4922 42H23.4609C22.6303 42 21.957 42.6715 21.957 43.5V69H18.6484V55.5C18.6484 54.6715 17.9752 54 17.1445 54H4.8125C3.98183 54 3.30859 54.6715 3.30859 55.5V69H1.50391C0.673233 69 0 69.6715 0 70.5C0 71.3285 0.673233 72 1.50391 72H75.4961C76.3268 72 77 71.3285 77 70.5C77 69.6715 76.3268 69 75.4961 69ZM61.6602 21H70.6836V69H61.6602V21ZM43.3125 33H52.3359V69H43.3125V33ZM24.9648 45H33.9883V69H24.9648V45ZM6.31641 57H15.6406V69H6.31641V57Z" fill="#fff" />
                                    <path d="M7.18887 44.359C7.66413 45.0369 8.60113 45.2051 9.28318 44.7299L67.0743 4.46777V7.5C67.0743 8.32852 67.7475 9 68.5782 9C69.4089 9 70.0821 8.32852 70.0821 7.5V1.5C70.0821 0.671484 69.4089 0 68.5782 0H62.5626C61.7319 0 61.0587 0.671484 61.0587 1.5C61.0587 2.32852 61.7319 3 62.5626 3H63.929L7.56073 42.2701C6.87986 42.7447 6.71361 43.6799 7.18887 44.359Z" fill="#fff" />
                                    <path d="M47.8242 39C46.9936 39 46.3203 39.6715 46.3203 40.5V55.5C46.3203 56.3285 46.9936 57 47.8242 57C48.6549 57 49.3281 56.3285 49.3281 55.5V40.5C49.3281 39.6715 48.6549 39 47.8242 39Z" fill="#fff" />
                                </svg>
                            </div>
                            <div class="counter__content">
                                <h2 class="count"><span class="counter-number">55</span>K</h2>
                                <p>Repeat Customers</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- counter-area-end -->

        <!-- section-line -->
        <div class="section__line">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </div>
        <!-- section-line-end -->

        <!-- team-area -->
        <section class="team__area section-bg section-py-140">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="team__content-wrap position-sticky">
                            <div class="section__title mb-20">
                                <span class="sub-title">Our Team Members</span>
                                <h2 class="title">See Our IT Professional Staff For you</h2>
                            </div>
                            <p>transforma tiveinvolves asseyour current inancial situat synergize grantsbvisualize strategic ediarey.</p>
                            <a href="team.php" class="tg-btn">See All Members
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M1 9L9 1M9 1H1M9 1V9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="team__item-wrap">
                            <div class="row gutter-80 gutter-y-40">
                                <div class="col-sm-6">
                                    <div class="team__item active">
                                        <div class="team__thumb">
                                            <a href="team-details.php"><img src="assets/img/team/team_img01.jpg" alt="img"></a>
                                            <ul class="list-wrap team__social">
                                                <li>
                                                    <a href="https://www.facebook.com/" target="_blank">
                                                        <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://x.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.instagram.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.pinterest.com/" target="_blank">
                                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="shape">
                                                <svg width="173" height="124" viewBox="0 0 173 124" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8 173C13.6667 148.667 41 98.8 105 94C185 88 61 11 216 8" stroke="currentColor" stroke-width="15" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="team__content">
                                            <h2 class="title"><a href="team-details.php">Ralph Edwards</a></h2>
                                            <span>Sr. Software Engineer</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="team__item">
                                        <div class="team__thumb">
                                            <a href="team-details.php"><img src="assets/img/team/team_img02.jpg" alt="img"></a>
                                            <ul class="list-wrap team__social">
                                                <li>
                                                    <a href="https://www.facebook.com/" target="_blank">
                                                        <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://x.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.instagram.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.pinterest.com/" target="_blank">
                                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="shape">
                                                <svg width="122" height="102" viewBox="0 0 122 102" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.00003 126.219C32.9035 88.7291 93.7711 25.303 130.014 71.5137C166.256 117.724 110.67 96.5588 78.346 80.1997C47.6437 58.7487 26.4529 14.1843 187.308 7.5348" stroke="currentColor" stroke-width="15" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="team__content">
                                            <h2 class="title"><a href="team-details.php">Wade Warren</a></h2>
                                            <span>Sr. Software Engineer</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="team__item">
                                        <div class="team__thumb">
                                            <a href="team-details.php"><img src="assets/img/team/team_img03.jpg" alt="img"></a>
                                            <ul class="list-wrap team__social">
                                                <li>
                                                    <a href="https://www.facebook.com/" target="_blank">
                                                        <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://x.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.instagram.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.pinterest.com/" target="_blank">
                                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="shape">
                                                <svg width="122" height="102" viewBox="0 0 122 102" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.00003 126.219C32.9035 88.7291 93.7711 25.303 130.014 71.5137C166.256 117.724 110.67 96.5588 78.346 80.1997C47.6437 58.7487 26.4529 14.1843 187.308 7.5348" stroke="currentColor" stroke-width="15" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="team__content">
                                            <h2 class="title"><a href="team-details.php">Jenny Wilson</a></h2>
                                            <span>Sr. Software Engineer</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="team__item">
                                        <div class="team__thumb">
                                            <a href="team-details.php"><img src="assets/img/team/team_img04.jpg" alt="img"></a>
                                            <ul class="list-wrap team__social">
                                                <li>
                                                    <a href="https://www.facebook.com/" target="_blank">
                                                        <svg width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M9.86031 11.25L10.4075 7.63046H6.9863V5.28164C6.9863 4.2914 7.46421 3.32617 8.99646 3.32617H10.5518V0.244531C10.5518 0.244531 9.14037 0 7.7909 0C4.97345 0 3.13183 1.73359 3.13183 4.87187V7.63046H0V11.25H3.13183V20H6.9863V11.25H9.86031Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://x.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M10.2337 7.28122L16.6351 0H15.118L9.55989 6.32204L5.12043 0H0L6.71329 9.56016L0 17.1955H1.51707L7.38684 10.5192L12.0751 17.1955H17.1955L10.2333 7.28122H10.2337ZM8.15595 9.64426L2.06363 1.11744H4.39374L15.1187 16.1288H12.7889L8.15595 9.64466V9.64426Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.instagram.com/" target="_blank">
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.79512 4.29904C6.29988 4.29904 4.28722 6.31911 4.28722 8.82352C4.28722 11.3279 6.29988 13.348 8.79512 13.348C11.2904 13.348 13.303 11.3279 13.303 8.82352C13.303 6.31911 11.2904 4.29904 8.79512 4.29904ZM8.79512 11.765C7.18263 11.765 5.86439 10.4459 5.86439 8.82352C5.86439 7.20117 7.17871 5.88202 8.79512 5.88202C10.4115 5.88202 11.7258 7.20117 11.7258 8.82352C11.7258 10.4459 10.4076 11.765 8.79512 11.765ZM14.5389 4.11397C14.5389 4.70069 14.0681 5.16929 13.4874 5.16929C12.9028 5.16929 12.436 4.69676 12.436 4.11397C12.436 3.53118 12.9068 3.05865 13.4874 3.05865C14.0681 3.05865 14.5389 3.53118 14.5389 4.11397ZM17.5245 5.18504C17.4578 3.77138 17.1361 2.51918 16.1043 1.48749C15.0764 0.455795 13.8287 0.132899 12.4203 0.0620196C10.9686 -0.0206732 6.61767 -0.0206732 5.16604 0.0620196C3.76149 0.128961 2.51387 0.451857 1.48204 1.48355C0.450202 2.51524 0.132412 3.76745 0.0617924 5.1811C-0.0205975 6.63807 -0.0205975 11.005 0.0617924 12.462C0.128489 13.8757 0.450202 15.1279 1.48204 16.1596C2.51387 17.1912 3.75757 17.5141 5.16604 17.585C6.61767 17.6677 10.9686 17.6677 12.4203 17.585C13.8287 17.5181 15.0764 17.1952 16.1043 16.1596C17.1322 15.1279 17.4539 13.8757 17.5245 12.462C17.6069 11.005 17.6069 6.64201 17.5245 5.18504ZM15.6492 14.0253C15.3432 14.7971 14.7507 15.3917 13.9778 15.7028C12.8205 16.1635 10.0741 16.0572 8.79512 16.0572C7.51611 16.0572 4.76586 16.1596 3.6124 15.7028C2.84343 15.3956 2.25101 14.801 1.94107 14.0253C1.48204 12.8637 1.58797 10.1072 1.58797 8.82352C1.58797 7.53981 1.48596 4.77945 1.94107 3.62175C2.24709 2.84995 2.83951 2.25535 3.6124 1.94427C4.76978 1.48355 7.51611 1.58987 8.79512 1.58987C10.0741 1.58987 12.8244 1.48749 13.9778 1.94427C14.7468 2.25141 15.3392 2.84601 15.6492 3.62175C16.1082 4.78339 16.0023 7.53981 16.0023 8.82352C16.0023 10.1072 16.1082 12.8676 15.6492 14.0253Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="https://www.pinterest.com/" target="_blank">
                                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M8.09703 0C4.0247 0 0 2.74089 0 7.1768C0 9.99783 1.57178 11.6007 2.52437 11.6007C2.91731 11.6007 3.14355 10.4947 3.14355 10.1822C3.14355 9.8095 2.20287 9.01608 2.20287 7.46532C2.20287 4.24357 4.63198 1.9595 7.77553 1.9595C10.4785 1.9595 12.479 3.51026 12.479 6.35934C12.479 8.48714 11.6335 12.4783 8.89483 12.4783C7.90651 12.4783 7.06109 11.757 7.06109 10.7231C7.06109 9.20843 8.10894 7.74181 8.10894 6.17902C8.10894 3.52629 4.38192 4.00715 4.38192 7.21287C4.38192 7.88607 4.46527 8.6314 4.76296 9.24449C4.21522 11.6247 3.09592 15.1711 3.09592 17.6234C3.09592 18.3808 3.20309 19.1261 3.27453 19.8835C3.40949 20.0357 3.34201 20.0197 3.5484 19.9436C5.54885 17.1786 5.4774 16.6377 6.38237 13.0192C6.87057 13.9569 8.13275 14.4618 9.13297 14.4618C13.3482 14.4618 15.2415 10.3144 15.2415 6.57573C15.2415 2.59663 11.836 0 8.09703 0Z" fill="currentColor" />
                                                        </svg>
                                                    </a>
                                                </li>
                                            </ul>
                                            <div class="shape">
                                                <svg width="173" height="124" viewBox="0 0 173 124" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8 173C13.6667 148.667 41 98.8 105 94C185 88 61 11 216 8" stroke="currentColor" stroke-width="15" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="team__content">
                                            <h2 class="title"><a href="team-details.php">Jane Cooper</a></h2>
                                            <span>Sr. Software Engineer</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team__shape">
                <img src="assets/img/team/team_shape.svg" alt="shape">
            </div>
        </section>
        <!-- team-area-end -->


        <!-- project-area -->
        <section class="project__area section-py-140 p-relative fix">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section__title text-center mb-50" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                            <span class="sub-title">Our Company Projects</span>
                            <h2 class="title">Explore our recent projects That We Have Done</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container custom-container-two">
                <div class="project__item-wrap">
                    <div class="project-active swiper-container fix" id="projectSlider" data-swiper-options='{
                        "loop": true,
                        "autoplay": { "delay": 6000 },
                        "breakpoints": {
                            "0": {
                                "spaceBetween": 10,
                                "slidesPerView": 1
                            },
                            "375": {
                                "spaceBetween": 20,
                                "slidesPerView": 1
                            },
                            "575": {
                                "spaceBetween": 20,
                                "slidesPerView": 2
                            },
                            "768": {
                                "spaceBetween": 20,
                                "slidesPerView": 2
                            },
                            "992": {
                                "spaceBetween": 20,
                                "slidesPerView": 3
                            },
                            "1200": {
                                "spaceBetween": 20,
                                "slidesPerView": 4
                            },
                            "1400": {
                                "spaceBetween": 30,
                                "slidesPerView": 4
                            }
                        },
                        "pagination": {
                            "el": ".project-pagination",
                            "clickable": true
                        }}'>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="project__item">
                                    <div class="project__thumb">
                                        <a href="project-details.php"><img src="assets/img/project/project_img07.jpg" alt="img"></a>
                                    </div>
                                    <div class="project__content">
                                        <h2 class="title"><a href="project-details.php">Futuristic Thinking</a></h2>
                                        <span>Technology</span>
                                    </div>
                                    <div class="project__icon">
                                        <a href="project-details.php">
                                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="project__item">
                                    <div class="project__thumb">
                                        <a href="project-details.php"><img src="assets/img/project/project_img08.jpg" alt="img"></a>
                                    </div>
                                    <div class="project__content">
                                        <h2 class="title"><a href="project-details.php">Cyber solutions</a></h2>
                                        <span>Technology</span>
                                    </div>
                                    <div class="project__icon">
                                        <a href="project-details.php">
                                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="project__item">
                                    <div class="project__thumb">
                                        <a href="project-details.php"><img src="assets/img/project/project_img09.jpg" alt="img"></a>
                                    </div>
                                    <div class="project__content">
                                        <h2 class="title"><a href="project-details.php">AI Development</a></h2>
                                        <span>Technology</span>
                                    </div>
                                    <div class="project__icon">
                                        <a href="project-details.php">
                                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="project__item">
                                    <div class="project__thumb">
                                        <a href="project-details.php"><img src="assets/img/project/project_img10.jpg" alt="img"></a>
                                    </div>
                                    <div class="project__content">
                                        <h2 class="title"><a href="project-details.php">Initiation & Planning</a></h2>
                                        <span>Technology</span>
                                    </div>
                                    <div class="project__icon">
                                        <a href="project-details.php">
                                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="project__item">
                                    <div class="project__thumb">
                                        <a href="project-details.php"><img src="assets/img/project/project_img03.jpg" alt="img"></a>
                                    </div>
                                    <div class="project__content">
                                        <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                        <span>Technology</span>
                                    </div>
                                    <div class="project__icon">
                                        <a href="project-details.php">
                                            <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="project-pagination"></div>
            <!-- <h2 class="overlay__text" data-sal="slide-up" data-sal-duration="700" data-sal-delay="200">Portfolio</h2> -->
        </section>
        <!-- project-area-end -->

        <!-- marquee-area -->
        <!-- <section class="marquee__area fix">
            <div class="slider__marquee clearfix marquee-wrap">
                <div class="marquee_mode marquee__group">
                    <h2 class="marquee__item">
                        <svg class="rotateme" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.4289 0H16.5711V6.76884L19.9561 0.90669L23.5445 2.97839L20.1595 8.84054L26.0216 5.45676L28.0933 9.04388L22.2312 12.4289H29V16.5711H22.2312L28.0933 19.9561L26.0216 23.5445L20.1595 20.1595L23.5445 26.0216L19.9561 28.0933L16.5711 22.2312V29H12.4289V22.2312L9.04388 28.0933L5.45548 26.0216L8.84054 20.1595L2.97839 23.5445L0.90669 19.9561L6.76884 16.5711H0V12.4289H6.76884L0.90669 9.04388L2.97839 5.45676L8.84054 8.84054L5.45676 2.97839L9.04388 0.90669L12.4289 6.76884V0Z" fill="currentColor" />
                        </svg>
                        Professional IT Consultancy
                    </h2>
                    <h2 class="marquee__item">
                        <svg class="rotateme" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.4289 0H16.5711V6.76884L19.9561 0.90669L23.5445 2.97839L20.1595 8.84054L26.0216 5.45676L28.0933 9.04388L22.2312 12.4289H29V16.5711H22.2312L28.0933 19.9561L26.0216 23.5445L20.1595 20.1595L23.5445 26.0216L19.9561 28.0933L16.5711 22.2312V29H12.4289V22.2312L9.04388 28.0933L5.45548 26.0216L8.84054 20.1595L2.97839 23.5445L0.90669 19.9561L6.76884 16.5711H0V12.4289H6.76884L0.90669 9.04388L2.97839 5.45676L8.84054 8.84054L5.45676 2.97839L9.04388 0.90669L12.4289 6.76884V0Z" fill="currentColor" />
                        </svg>
                        We Carry more Than Just Good Coding Skills
                    </h2>
                    <h2 class="marquee__item">
                        <svg class="rotateme" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.4289 0H16.5711V6.76884L19.9561 0.90669L23.5445 2.97839L20.1595 8.84054L26.0216 5.45676L28.0933 9.04388L22.2312 12.4289H29V16.5711H22.2312L28.0933 19.9561L26.0216 23.5445L20.1595 20.1595L23.5445 26.0216L19.9561 28.0933L16.5711 22.2312V29H12.4289V22.2312L9.04388 28.0933L5.45548 26.0216L8.84054 20.1595L2.97839 23.5445L0.90669 19.9561L6.76884 16.5711H0V12.4289H6.76884L0.90669 9.04388L2.97839 5.45676L8.84054 8.84054L5.45676 2.97839L9.04388 0.90669L12.4289 6.76884V0Z" fill="currentColor" />
                        </svg>
                        Check Our Latest Portfolios
                    </h2>
                    <h2 class="marquee__item">
                        <svg class="rotateme" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.4289 0H16.5711V6.76884L19.9561 0.90669L23.5445 2.97839L20.1595 8.84054L26.0216 5.45676L28.0933 9.04388L22.2312 12.4289H29V16.5711H22.2312L28.0933 19.9561L26.0216 23.5445L20.1595 20.1595L23.5445 26.0216L19.9561 28.0933L16.5711 22.2312V29H12.4289V22.2312L9.04388 28.0933L5.45548 26.0216L8.84054 20.1595L2.97839 23.5445L0.90669 19.9561L6.76884 16.5711H0V12.4289H6.76884L0.90669 9.04388L2.97839 5.45676L8.84054 8.84054L5.45676 2.97839L9.04388 0.90669L12.4289 6.76884V0Z" fill="currentColor" />
                        </svg>
                        Let's Elevate Your Business with Strategic IT Solutions
                    </h2>
                    <h2 class="marquee__item">
                        <svg class="rotateme" width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.4289 0H16.5711V6.76884L19.9561 0.90669L23.5445 2.97839L20.1595 8.84054L26.0216 5.45676L28.0933 9.04388L22.2312 12.4289H29V16.5711H22.2312L28.0933 19.9561L26.0216 23.5445L20.1595 20.1595L23.5445 26.0216L19.9561 28.0933L16.5711 22.2312V29H12.4289V22.2312L9.04388 28.0933L5.45548 26.0216L8.84054 20.1595L2.97839 23.5445L0.90669 19.9561L6.76884 16.5711H0V12.4289H6.76884L0.90669 9.04388L2.97839 5.45676L8.84054 8.84054L5.45676 2.97839L9.04388 0.90669L12.4289 6.76884V0Z" fill="currentColor" />
                        </svg>
                        Network Infrastructure Solutions
                    </h2>
                </div>
            </div>
        </section> -->
        <!-- marquee-area-end -->

        <!-- testimonial-area -->
        <section class="testimonial__area section-bg section-py-140 fix">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="testimonial__content-wrap">
                            <div class="section__title mb-20">
                                <span class="sub-title">Our Latest Testimonials</span>
                                <h2 class="title">What Our Customers Say About IT Solutions</h2>
                            </div>
                            <p>transforma tiveinvolves asseyour current inancial situat synergize grantsbvisualize strategic ediarey.</p>
                            <div class="testimonial__nav-wrap">
                                <button class="testimonial-button-prev">
                                    <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.6924 10.5H1.30761M1.30761 10.5L10.5 1.30762M1.30761 10.5L10.5 19.6924" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                                <button class="testimonial-button-next">
                                    <svg width="22" height="21" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1.80761 10.1924H20.1924M20.1924 10.1924L11 1M20.1924 10.1924L11 19.3848" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="testimonial__item-wrap">
                            <div class="swiper-container testimonial-active fix" id="testimonialSlider" data-swiper-options='{
                                "loop": true,
                                "autoplay": { "delay": 6000 },
                                "breakpoints": {
                                    "0": {
                                        "spaceBetween": 10,
                                        "slidesPerView": 1
                                    },
                                    "375": {
                                        "spaceBetween": 20,
                                        "slidesPerView": 1
                                    },
                                    "575": {
                                        "spaceBetween": 20,
                                        "slidesPerView": 2
                                    },
                                    "768": {
                                        "spaceBetween": 20,
                                        "slidesPerView": 3
                                    },
                                    "992": {
                                        "spaceBetween": 20,
                                        "slidesPerView": 3
                                    },
                                    "1200": {
                                        "spaceBetween": 20,
                                        "slidesPerView": 4
                                    },
                                    "1400": {
                                        "spaceBetween": 24,
                                        "slidesPerView": 3
                                    }
                                },
                                "navigation": {
                                    "nextEl": ".testimonial-button-next",
                                    "prevEl": ".testimonial-button-prev"
                                }}'>
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="testimonial__item">
                                            <div class="rating">
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                            </div>
                                            <h2 class="title">Great Product! Highly Recommended!</h2>
                                            <p>Great Quality Products Withery GoodPackaging unknown printer took a galle rambled it make pecimive centuries</p>
                                            <div class="testimonial__avatar">
                                                <div class="thumb">
                                                    <img src="assets/img/images/testi_avatar01.jpg" alt="img">
                                                </div>
                                                <div class="content">
                                                    <h2 class="name">Darrell Steward</h2>
                                                    <span>Sr.Designer</span>
                                                </div>
                                            </div>
                                            <div class="shape">
                                                <img src="assets/img/images/testi_item_shape.svg" alt="shape">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial__item">
                                            <div class="rating">
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                            </div>
                                            <h2 class="title">Great Product! Highly Recommended!</h2>
                                            <p>Great Quality Products Withery GoodPackaging unknown printer took a galle rambled it make pecimive centuries</p>
                                            <div class="testimonial__avatar">
                                                <div class="thumb">
                                                    <img src="assets/img/images/testi_avatar02.jpg" alt="img">
                                                </div>
                                                <div class="content">
                                                    <h2 class="name">Annette Black</h2>
                                                    <span>Sr.Designer</span>
                                                </div>
                                            </div>
                                            <div class="shape">
                                                <img src="assets/img/images/testi_item_shape.svg" alt="shape">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial__item">
                                            <div class="rating">
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                            </div>
                                            <h2 class="title">Great Product! Highly Recommended!</h2>
                                            <p>Great Quality Products Withery GoodPackaging unknown printer took a galle rambled it make pecimive centuries</p>
                                            <div class="testimonial__avatar">
                                                <div class="thumb">
                                                    <img src="assets/img/images/testi_avatar03.jpg" alt="img">
                                                </div>
                                                <div class="content">
                                                    <h2 class="name">Mr.Robey Alexa</h2>
                                                    <span>Sr.Designer</span>
                                                </div>
                                            </div>
                                            <div class="shape">
                                                <img src="assets/img/images/testi_item_shape.svg" alt="shape">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial__item">
                                            <div class="rating">
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                                <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.20504 0.5L10.6419 5.43691L16.0915 6.23344L12.1483 10.0741L13.0789 15.5L8.20504 12.9369L3.33122 15.5L4.26182 10.0741L0.318604 6.23344L5.76813 5.43691L8.20504 0.5Z" fill="currentColor" />
                                                </svg>
                                            </div>
                                            <h2 class="title">Great Product! Highly Recommended!</h2>
                                            <p>Great Quality Products Withery GoodPackaging unknown printer took a galle rambled it make pecimive centuries</p>
                                            <div class="testimonial__avatar">
                                                <div class="thumb">
                                                    <img src="assets/img/images/testi_avatar04.jpg" alt="img">
                                                </div>
                                                <div class="content">
                                                    <h2 class="name">Courtney Henry</h2>
                                                    <span>Sr.Designer</span>
                                                </div>
                                            </div>
                                            <div class="shape">
                                                <img src="assets/img/images/testi_item_shape.svg" alt="shape">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial-area-end -->

        <!-- blog-post-area -->
        <section class="blog-post__area section-py-140 fix">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section__title text-center mb-50" data-sal="slide-up" data-sal-duration="700" data-sal-delay="100">
                            <span class="sub-title">New Blogs & Post</span>
                            <h2 class="title">Latest News & Articles From The Blog Posts</h2>
                        </div>
                    </div>
                </div>
                <div class="row gutter-y-40">
                    <div class="col-lg-6">
                        <div class="blog-post__item">
                            <div class="blog-post__thumb">
                                <a href="blog-details.php"><img src="assets/img/blog/blog_img01.jpg" alt="img"></a>
                            </div>
                            <div class="blog-post__content">
                                <ul class="blog-post__meta list-wrap">
                                    <li>by <a href="blog-details.php">admin</a></li>
                                    <li>12 Sep, 2025</li>
                                </ul>
                                <h2 class="post-title"><a href="blog-details.php">Boost your startup business with our
                                digital agency</a></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="blog-post__item-wrap">
                            <div class="blog-post__item-two">
                                <div class="blog-post__thumb-two">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img02.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-two">
                                    <ul class="list-wrap blog-post__meta blog-post__meta-two">
                                        <li>by <a href="blog-details.php">admin</a></li>
                                        <li>12 Sep, 2025</li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">What is cyber security a beginner’s guide</a></h2>
                                    <a href="blog-details.php" class="tg-text-btn">Read More
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="blog-post__item-two">
                                <div class="blog-post__thumb-two">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img03.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-two">
                                    <ul class="list-wrap blog-post__meta blog-post__meta-two">
                                        <li>by <a href="blog-details.php">admin</a></li>
                                        <li>12 Sep, 2025</li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Power of Technology for the Middle Market</a></h2>
                                    <a href="blog-details.php" class="tg-text-btn">Read More
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="blog-post__item-two">
                                <div class="blog-post__thumb-two">
                                    <a href="blog-details.php"><img src="assets/img/blog/blog_img04.jpg" alt="img"></a>
                                </div>
                                <div class="blog-post__content-two">
                                    <ul class="list-wrap blog-post__meta blog-post__meta-two">
                                        <li>by <a href="blog-details.php">admin</a></li>
                                        <li>12 Sep, 2025</li>
                                    </ul>
                                    <h2 class="post-title"><a href="blog-details.php">Analyze Cash Flow & Boost Your Business Growth</a></h2>
                                    <a href="blog-details.php" class="tg-text-btn">Read More
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                            <path d="M1 11L11 1M11 1H1M11 1V11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- blog-post-area-end -->

        <!-- contact-area -->
        <section class="contact__area">
            <div class="container">
                <div class="contact__inner-wrap">
                    <div class="row align-items-center">
                        <div class="col-lg-6" data-sal="slide-right" data-sal-duration="700" data-sal-delay="100">
                            <div class="contact__content">
                                <div class="section__title mb-10">
                                    <span class="sub-title">Free Consultation</span>
                                    <h2 class="title">Book a Free Consultation</h2>
                                </div>
                                <p>transforma tiveinvolves asseyour current inancial situat synergize grantsbvisualize strategic ediarey.</p>
                                <div class="contact__info-list">
                                    <div class="contact__info-item">
                                        <div class="icon">
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M25 12.5761C25 21.0609 14.1667 28.3337 14.1667 28.3337C14.1667 28.3337 3.33334 21.0609 3.33334 12.5761C3.33334 9.68281 4.47471 6.90804 6.50635 4.86219C8.538 2.81634 11.2935 1.66699 14.1667 1.66699C17.0399 1.66699 19.7954 2.81634 21.827 4.86219C23.8586 6.90804 25 9.68281 25 12.5761Z" stroke="currentColor" stroke-width="2.16667" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M14.1667 16.2124C16.161 16.2124 17.7778 14.5844 17.7778 12.5761C17.7778 10.5678 16.161 8.93972 14.1667 8.93972C12.1723 8.93972 10.5556 10.5678 10.5556 12.5761C10.5556 14.5844 12.1723 16.2124 14.1667 16.2124Z" stroke="currentColor" stroke-width="2.16667" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <h2 class="title">Address</h2>
                                            <p> HONG KONG</p>
                                        </div>
                                    </div>
                                    <div class="contact__info-item">
                                        <div class="icon">
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M28.3333 7.5C28.3333 6.125 27.1333 5 25.6667 5H4.33332C2.86666 5 1.66666 6.125 1.66666 7.5M28.3333 7.5V22.5C28.3333 23.875 27.1333 25 25.6667 25H4.33332C2.86666 25 1.66666 23.875 1.66666 22.5V7.5M28.3333 7.5L15 16.2501L1.66666 7.5" stroke="currentColor" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <h2 class="title">E-mail</h2>
                                            <a href="mailto:hello@divainetech.io">hello@divainetech.io</a>
                                        </div>
                                    </div>
                                    <div class="contact__info-item">
                                        <div class="icon">
                                            <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M26.6197 20.8025V24.3151C26.6211 24.6412 26.5543 24.964 26.4236 25.2627C26.293 25.5615 26.1014 25.8297 25.8611 26.0502C25.6208 26.2706 25.3371 26.4384 25.0282 26.5429C24.7193 26.6474 24.392 26.6862 24.0672 26.6568C20.4643 26.2653 17.0034 25.0342 13.9626 23.0623C11.1336 21.2646 8.73509 18.8661 6.93742 16.0371C4.95862 12.9825 3.72718 9.50477 3.34285 5.88562C3.31359 5.56183 3.35207 5.2355 3.45584 4.92741C3.55961 4.61931 3.72639 4.33619 3.94557 4.09608C4.16475 3.85598 4.43153 3.66414 4.72891 3.53278C5.0263 3.40142 5.34777 3.33343 5.67288 3.33312H9.18548C9.75372 3.32753 10.3046 3.52875 10.7354 3.89927C11.1663 4.2698 11.4477 4.78435 11.5272 5.34702C11.6755 6.47113 11.9504 7.57486 12.3468 8.63716C12.5044 9.05624 12.5385 9.5117 12.4451 9.94956C12.3517 10.3874 12.1347 10.7893 11.8199 11.1077L10.3329 12.5947C11.9997 15.526 14.4268 17.9531 17.3582 19.6199L18.8452 18.1329C19.1635 17.8181 19.5654 17.6012 20.0033 17.5078C20.4411 17.4144 20.8966 17.4485 21.3157 17.606C22.378 18.0024 23.4817 18.2774 24.6058 18.4256C25.1746 18.5059 25.694 18.7923 26.0654 19.2306C26.4367 19.6688 26.634 20.2283 26.6197 20.8025Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                        <div class="content">
                                            <h2 class="title">Emergency Contact</h2>
                                            <a href="tel: +971 552783479"> +971 552783479</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6" data-sal="slide-left" data-sal-duration="700" data-sal-delay="100">
                            <div class="contact__form-wrap">
                                <form id="contact-form" action="assets/mail.php" class="contact__form" method="POST">
                                    <div class="row gutter-20">
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="text" name="name" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="text" name="name" placeholder="Last Name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="email" name="email" placeholder="E-mail">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-grp">
                                                <input type="number" name="number" placeholder="Phone">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-grp">
                                        <input type="url" name="website" placeholder="Website Url">
                                    </div>
                                    <div class="form-grp">
                                        <textarea name="messages" placeholder="Comments . . ."></textarea>
                                    </div>
                                    <button type="submit" class="tg-btn">Send Message</button>
                                </form>
                                <p class="ajax-response mb-0"></p>
                            </div>
                        </div>
                    </div>
                    <img src="assets/img/images/map.svg" alt="shape" class="shape">
                </div>
            </div>
        </section>
        <!-- contact-area-end -->


 <?php
	include_once ('elements/footer.php')
?>