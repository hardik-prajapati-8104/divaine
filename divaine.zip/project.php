<?php
	include_once ('elements/header.php')
?>
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg fix" data-background="assets/img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb__content">
                            <h2 class="title">Our Project</h2>
                            <nav class="breadcrumb">
                                <span property="itemListElement" typeof="ListItem">
                                    <a href="index.php">Home</a>
                                </span>
                                <span class="breadcrumb-separator">/</span>
                                <span property="itemListElement" typeof="ListItem">Project</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- project-area -->
        <section class="project__area section-py-140">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section__title section__title-two text-center mb-50">
                            <span class="sub-title">Our Company Projects</span>
                            <h2 class="title">Explore our recent projects That We Have Done</h2>
                        </div>
                    </div>
                </div>
                <div class="project__inner-item">
                    <div class="row gutter-y-40">
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img07.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Futuristic Thinking</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img08.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Cyber solutions</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img09.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">AI Development</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img10.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Initiation & Planning</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img03.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img04.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img05.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img06.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="project__item">
                                <div class="project__thumb">
                                    <a href="project-details.php"><img src="assets/img/project/project_img01.jpg" alt="img"></a>
                                </div>
                                <div class="project__content">
                                    <h2 class="title"><a href="project-details.php">Testing & Maintenance</a></h2>
                                    <span>Technology</span>
                                </div>
                                <div class="project__icon">
                                    <a href="project-details.php">
                                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 17L17 2M17 2H2M17 2V17" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- project-area-end -->

<?php
	include_once ('elements/footer.php')
?>